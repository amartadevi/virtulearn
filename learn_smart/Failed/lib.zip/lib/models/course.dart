class Course {
  final int id;
  final String name;
  final String code;
  final String description;
  final String createdByUsername;
  final String createdByRole;
  final List<String> students;

  Course({
    required this.id,
    required this.name,
    required this.code,
    required this.description,
    required this.createdByUsername,
    required this.createdByRole,
    required this.students,
  });

  factory Course.fromJson(Map<String, dynamic> json) {
    return Course(
      id: json['id'],
      name: json['name'],
      code: json['code'],
      description: json['description'],
      createdByUsername: json['created_by']['username'],
      createdByRole: json['created_by']['role'],
      students: List<String>.from(json['students']),
    );
  }
}
