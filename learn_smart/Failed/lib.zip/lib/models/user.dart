class User {
  String name;
  String token;
  int id;
  String imageUrl;
  String role;

  User(
      {required this.name,
      required this.id,
      required this.imageUrl,
      required this.token,
      required this.role});

  bool isStudent(String role) {
    if (this.role == 'student') {
      return true;
    } else {
      return false;
    }
  }
}
