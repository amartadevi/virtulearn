import 'package:flutter/material.dart';
import 'package:learn_smart/models/enrollment_model.dart';
import 'package:learn_smart/view_models/auth_view_model.dart';
import 'package:provider/provider.dart';

class EnrollmentRequestsScreen extends StatefulWidget {
  @override
  _EnrollmentRequestsScreenState createState() =>
      _EnrollmentRequestsScreenState();
}

class _EnrollmentRequestsScreenState extends State<EnrollmentRequestsScreen> {
  String? userRole;
  String? userToken;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final authViewModel = Provider.of<AuthViewModel>(context, listen: false);
      final enrollmentModel =
          Provider.of<EnrollmentModel>(context, listen: false);

      authViewModel.fetchUserRoleAndId().then((_) {
        setState(() {
          userRole = authViewModel.role;
          userToken = authViewModel.token;
        });
        if (userRole != null && userToken != null) {
          enrollmentModel.fetchEnrollmentRequests(userRole!, userToken!);
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final enrollmentModel = Provider.of<EnrollmentModel>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Enrollment Requests'),
      ),
      body: enrollmentModel.isLoading
          ? Center(child: CircularProgressIndicator())
          : enrollmentModel.hasError
              ? Center(child: Text('Error fetching enrollment requests'))
              : ListView.builder(
                  itemCount: enrollmentModel.enrollmentRequests.length,
                  itemBuilder: (context, index) {
                    final request = enrollmentModel.enrollmentRequests[index];
                    return ListTile(
                      title: Text(
                          '${request['course_name']} - ${request['student_username']}'),
                      subtitle: Text('Status: ${request['status']}'),
                      trailing: userRole == 'teacher'
                          ? Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: Icon(Icons.check),
                                  onPressed: () async {
                                    if (userToken != null) {
                                      await enrollmentModel.approveEnrollment(
                                          request['id'], userToken!);
                                      final snackBar = SnackBar(
                                        content: Text(enrollmentModel.hasError
                                            ? 'Failed to approve enrollment request'
                                            : 'Enrollment request approved'),
                                      );
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(snackBar);
                                    }
                                  },
                                ),
                                IconButton(
                                  icon: Icon(Icons.close),
                                  onPressed: () async {
                                    if (userToken != null) {
                                      await enrollmentModel.denyEnrollment(
                                          request['id'], userToken!);
                                      final snackBar = SnackBar(
                                        content: Text(enrollmentModel.hasError
                                            ? 'Failed to deny enrollment request'
                                            : 'Enrollment request denied'),
                                      );
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(snackBar);
                                    }
                                  },
                                ),
                              ],
                            )
                          : null,
                    );
                  },
                ),
    );
  }
}
