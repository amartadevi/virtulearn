import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:learn_smart/view_models/auth_view_model.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final VoidCallback? onMenuPressed;
  final VoidCallback? onSearchPressed;

  const CustomAppBar({
    required this.title,
    this.onMenuPressed,
    this.onSearchPressed,
  });

  bool get _isHome => title == 'Home';

  @override
  Widget build(BuildContext context) {
    final authViewModel = Provider.of<AuthViewModel>(context);
    final username = authViewModel.username ?? "User";
    final profileImage =
        authViewModel.profileImage ?? 'assets/icons/default_profile.png';

    return Container(
      padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
      decoration: BoxDecoration(
        color: Colors.blue,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(20),
          bottomRight: Radius.circular(20),
        ),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundImage: authViewModel.profileImage != null
                      ? NetworkImage(profileImage)
                      : const AssetImage('assets/icons/default_profile.png')
                          as ImageProvider,
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (_isHome)
                          Text(
                            'Hello $username,',
                            style: const TextStyle(
                                color: Colors.white, fontSize: 16),
                          ),
                        Text(
                          _isHome ? 'Good Morning' : title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                IconButton(
                  icon:
                      const Icon(Icons.notifications_none, color: Colors.white),
                  onPressed: onMenuPressed ?? () {},
                ),
              ],
            ),
          ),
          if (_isHome)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: SearchBar(onSearchPressed: onSearchPressed),
            ),
        ],
      ),
    );
  }

  @override
  Size get preferredSize =>
      _isHome ? const Size.fromHeight(180) : const Size.fromHeight(80);
}

class SearchBar extends StatelessWidget {
  final VoidCallback? onSearchPressed;

  const SearchBar({this.onSearchPressed});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
      ),
      child: TextField(
        onTap: onSearchPressed,
        decoration: const InputDecoration(
          hintText: 'Search Course',
          suffixIcon: Icon(Icons.search),
          border: InputBorder.none,
          contentPadding: EdgeInsets.all(20),
        ),
      ),
    );
  }
}
