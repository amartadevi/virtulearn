import 'package:get/get.dart';
import 'package:learn_smart/models/enrollment_request.dart';
import 'package:learn_smart/screens/course_detail_screen.dart';
import 'package:learn_smart/screens/dashboard_screen.dart';
import 'package:learn_smart/screens/notifications_screen.dart';
import 'package:learn_smart/screens/module_detail_screen.dart';
import 'package:learn_smart/screens/quiz_detail_screen.dart';
import 'package:learn_smart/screens/create_module_screen.dart';
import 'package:learn_smart/screens/create_note_screen.dart';
import 'package:learn_smart/screens/create_quiz_screen.dart';
import 'package:learn_smart/screens/edit_note_screen.dart';
import 'package:learn_smart/screens/edit_quiz_screen.dart';
import 'package:provider/provider.dart';

import 'result_screen.dart';
import '../view_models/enrollment_view_model.dart';

class AppRoutes {
  static final routes = [
    GetPage(name: '/dashboard', page: () => DashboardScreen()),
    GetPage(
      name: '/course/:id',
      page: () => CourseDetailScreen(
        courseId: int.parse(Get.parameters['id']!),
      ),
    ),
    GetPage(
      name: '/module-detail',
      page: () => ModuleDetailScreen(
        moduleId: Get.arguments['moduleId'],
      ),
    ),
    GetPage(
      name: '/quiz-detail',
      page: () => QuizDetailScreen(
        quizId: Get.arguments['quizId'],
        moduleId: Get.arguments['moduleId'],
      ),
    ),
    GetPage(
      name: '/result',
      page: () => ResultScreen(
        quizId: Get.arguments['quizId'],
        moduleId: Get.arguments['moduleId'],
      ),
    ),
    GetPage(
      name: '/notifications',
      page: () => MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (_) => EnrollmentViewModel()),
        ],
        child: NotificationsScreen(),
      ),
    ),
    GetPage(name: '/create-module', page: () => CreateModuleScreen()),
    GetPage(name: '/create-note', page: () => CreateNoteScreen()),
    GetPage(name: '/create-quiz', page: () => CreateQuizScreen()),
    GetPage(name: '/edit-note', page: () => EditNoteScreen()),
    GetPage(name: '/edit-quiz', page: () => EditQuizScreen()),
    GetPage(
        name: '/enrollment-requests', page: () => EnrollmentRequestsScreen()),
  ];
}
