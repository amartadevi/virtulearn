import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:learn_smart/screens/app_bar.dart';
import 'package:learn_smart/view_models/enrollment_view_model.dart';
import 'package:learn_smart/view_models/module_view_model.dart';
import 'package:learn_smart/view_models/auth_view_model.dart';
import 'package:learn_smart/view_models/course_view_model.dart';
import 'package:provider/provider.dart';

class CourseDetailScreen extends StatefulWidget {
  final int courseId;

  CourseDetailScreen({Key? key, required this.courseId}) : super(key: key);

  @override
  _CourseDetailScreenState createState() => _CourseDetailScreenState();
}

class _CourseDetailScreenState extends State<CourseDetailScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final courseViewModel =
          Provider.of<CourseViewModel>(context, listen: false);
      final moduleViewModel =
          Provider.of<ModuleViewModel>(context, listen: false);
      final authViewModel = Provider.of<AuthViewModel>(context, listen: false);
      final enrollmentViewModel =
          Provider.of<EnrollmentViewModel>(context, listen: false);

      courseViewModel.updateToken(authViewModel.token);
      moduleViewModel.updateToken(authViewModel.token);
      enrollmentViewModel.updateToken(authViewModel.token);

      if (authViewModel.token != null) {
        courseViewModel.fetchCourseDetail(widget.courseId);
        moduleViewModel.fetchModules(widget.courseId);
        enrollmentViewModel.fetchEnrollmentRequests('student');
      }
    });
  }

  bool _isEnrolled(EnrollmentViewModel enrollmentViewModel, int courseId) {
    return enrollmentViewModel.enrollmentRequests.any(
      (request) =>
          request['course'] == courseId && request['status'] == 'approved',
    );
  }

  @override
  Widget build(BuildContext context) {
    final authViewModel = Provider.of<AuthViewModel>(context);
    final courseViewModel = Provider.of<CourseViewModel>(context);
    final moduleViewModel = Provider.of<ModuleViewModel>(context);
    final enrollmentViewModel = Provider.of<EnrollmentViewModel>(context);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            // Handle back navigation
          },
        ),
        title: Text(
          'Course Detail',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: courseViewModel.isLoading
          ? const Center(child: CircularProgressIndicator())
          : courseViewModel.hasError
              ? Center(
                  child: Text(courseViewModel.errorMessage ??
                      'Error loading course details'))
              : SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildHeader(courseViewModel, authViewModel),
                        const SizedBox(height: 24),
                        _buildCourseOverview(courseViewModel),
                        const SizedBox(height: 24),
                        Text(
                          'Modules',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 10),
                        _buildModulesList(moduleViewModel, authViewModel),
                      ],
                    ),
                  ),
                ),
      bottomNavigationBar: (authViewModel.role == 'student' &&
              !_isEnrolled(enrollmentViewModel, widget.courseId))
          ? Padding(
              padding: const EdgeInsets.all(16.0),
              child: SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: () {
                    _showEnrollDialog(context, widget.courseId);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xff0095FF),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                  ),
                  child: const Text(
                    'Enroll',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            )
          : null,
    );
  }

  Widget _buildHeader(
      CourseViewModel courseViewModel, AuthViewModel authViewModel) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Image.asset(
            'assets/icons/flutter.jpg', // Replace with actual image URL
            height: 200,
            width: double.infinity,
            fit: BoxFit.cover,
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            CircleAvatar(
              backgroundImage: AssetImage(
                  'assets/screens/background.png'), // Replace with actual image URL
              radius: 20,
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Instructed by',
                  style: TextStyle(color: Colors.grey, fontSize: 12),
                ),
                Text(
                  courseViewModel.courseDetails['createdByUsername'] ??
                      'Not Found!',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildCourseOverview(CourseViewModel courseViewModel) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Course Overview',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        Text(
          courseViewModel.courseDetails['description'] ?? '',
          style: TextStyle(color: Colors.grey[600], height: 1.5),
        ),
      ],
    );
  }

  Widget _buildModulesList(
      ModuleViewModel moduleViewModel, AuthViewModel authViewModel) {
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: moduleViewModel.modules.length,
      itemBuilder: (context, index) {
        final module = moduleViewModel.modules[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 10.0),
          child: ModuleCard(
            module: Module(
              title: module['title'] ?? '',
              author: module['description'] ?? '',
              imagePath:
                  'assets/icons/flutter.jpg', // Using asset image for now
            ),
            onEdit: authViewModel.role != 'student'
                ? () {
                    _showEditModuleDialog(context, module);
                  }
                : null,
            onDelete: authViewModel.role != 'student'
                ? () async {
                    await moduleViewModel.deleteModule(
                        module['id'], widget.courseId);
                    Navigator.of(context).pop();
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Module deleted')),
                    );
                  }
                : null,
            onTap: () {
              Get.toNamed('/module-detail', arguments: {
                'moduleId': module['id'],
                'title': module['title'],
              });
            },
          ),
        );
      },
    );
  }

  void _showEditModuleDialog(BuildContext context, dynamic module) {
    final _formKey = GlobalKey<FormState>();
    String? _title = module['title'];
    String? _description = module['description'];

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Edit Module'),
          content: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  initialValue: _title,
                  decoration: const InputDecoration(labelText: 'Title'),
                  onSaved: (value) {
                    _title = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a title';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  initialValue: _description,
                  decoration: const InputDecoration(labelText: 'Description'),
                  onSaved: (value) {
                    _description = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a description';
                    }
                    return null;
                  },
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (_formKey.currentState!.validate()) {
                  _formKey.currentState!.save();
                  final moduleViewModel =
                      Provider.of<ModuleViewModel>(context, listen: false);
                  bool success = await moduleViewModel.updateModule(
                      module['id'], widget.courseId, _title!, _description!);
                  if (success) {
                    Navigator.of(context).pop();
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Module updated successfully'),
                      ),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Failed to update module'),
                      ),
                    );
                  }
                }
              },
              child: const Text('Update'),
            ),
          ],
        );
      },
    );
  }

  void _showEnrollDialog(BuildContext context, int courseId) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Enroll in Course'),
          content:
              const Text('Are you sure you want to enroll in this course?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                final enrollmentViewModel =
                    Provider.of<EnrollmentViewModel>(context, listen: false);
                await enrollmentViewModel.sendEnrollmentRequest(courseId);
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Enrollment request sent')),
                );
              },
              child: const Text('Enroll'),
            ),
          ],
        );
      },
    );
  }
}

class ModuleCard extends StatelessWidget {
  final Module module;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;
  final VoidCallback? onTap;

  ModuleCard({
    required this.module,
    this.onEdit,
    this.onDelete,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: module.color,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Image.asset(
                module.imagePath,
                width: 50,
                height: 50,
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      module.title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      module.author,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              if (onEdit != null)
                IconButton(
                  icon: const Icon(Icons.edit, color: Colors.white),
                  onPressed: onEdit,
                ),
              if (onDelete != null)
                IconButton(
                  icon: const Icon(Icons.delete, color: Colors.white),
                  onPressed: onDelete,
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class Module {
  final String title;
  final String author;
  final String imagePath;
  final Color color;

  Module({
    required this.title,
    required this.author,
    required this.imagePath,
    this.color = Colors.blue,
  });
}
