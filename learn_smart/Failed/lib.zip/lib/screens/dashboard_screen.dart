import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:get/get.dart';
import 'package:learn_smart/screens/app_bar.dart';
import 'package:learn_smart/screens/bottom_navigation.dart';
import 'package:learn_smart/view_models/auth_view_model.dart';
import 'package:learn_smart/view_models/course_view_model.dart';
import 'package:learn_smart/view_models/enrollment_view_model.dart';
import 'package:motion_tab_bar_v2/motion-tab-controller.dart';

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with TickerProviderStateMixin {
  late MotionTabBarController _motionTabBarController;
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final authViewModel = Provider.of<AuthViewModel>(context, listen: false);
      final courseViewModel =
          Provider.of<CourseViewModel>(context, listen: false);
      final enrollmentViewModel =
          Provider.of<EnrollmentViewModel>(context, listen: false);

      await authViewModel.fetchUserRoleAndId();
      await courseViewModel.fetchCourses();
      await enrollmentViewModel.fetchEnrollmentRequests(authViewModel.role!);
    });

    _motionTabBarController = MotionTabBarController(
      initialIndex: 0,
      length: 4,
      vsync: this,
    );
  }

  @override
  void dispose() {
    _motionTabBarController.dispose();
    super.dispose();
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
      _motionTabBarController.index = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final authViewModel = Provider.of<AuthViewModel>(context);

    return Scaffold(
      appBar: CustomAppBar(
        title: 'Home',
        onMenuPressed: () {
          // Handle menu press
        },
        onSearchPressed: () {
          // Handle search press
        },
      ),
      body: SafeArea(
        child: _buildCourseListScreen(context),
      ),
      bottomNavigationBar: BottomNavigation(
        controller: _motionTabBarController,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }

  Widget _buildCourseListScreen(BuildContext context) {
    final courseViewModel = Provider.of<CourseViewModel>(context);

    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionTitle('My Courses'),
            const SizedBox(height: 10),
            _buildCourseGrid(courseViewModel.courses),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: Theme.of(context)
              .textTheme
              .headlineLarge
              ?.copyWith(fontWeight: FontWeight.bold),
        ),
        TextButton(
          onPressed: () {},
          child: Text(
            'See All',
            style: Theme.of(context)
                .textTheme
                .bodyLarge
                ?.copyWith(color: const Color(0xff00A2E8)),
          ),
        ),
      ],
    );
  }

  Widget _buildCourseGrid(List<dynamic> courses) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: courses.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.92,
        crossAxisSpacing: 15,
        mainAxisSpacing: 15,
      ),
      itemBuilder: (context, index) {
        final course = courses[index];
        return _buildCourseCard(course);
      },
    );
  }

  Widget _buildCourseCard(dynamic course) {
    final authViewModel = Provider.of<AuthViewModel>(context, listen: false);
    final enrollmentViewModel =
        Provider.of<EnrollmentViewModel>(context, listen: false);

    return GestureDetector(
      onTap: () async {
        final isEnrolled = await enrollmentViewModel.isUserEnrolled(
            course['id'], authViewModel.userId!);

        Get.toNamed('/course/${course['id']}', arguments: {
          'isEnrolled': isEnrolled,
        });
      },
      child: Card(
        elevation: 3,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
              child: Image.asset(
                'assets/icons/flutter.jpg',
                fit: BoxFit.cover,
                height: 100,
                width: double.infinity,
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      course['name'],
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '${course['students'].length} Students',
                          style:
                              const TextStyle(color: Colors.grey, fontSize: 12),
                        ),
                        if (authViewModel.role == 'student')
                          Consumer<EnrollmentViewModel>(
                            builder: (context, enrollmentVM, _) {
                              final isEnrolled = enrollmentVM.enrollmentRequests
                                  .any((request) =>
                                      request['course'] == course['id'] &&
                                      request['status'] == 'approved');

                              return isEnrolled
                                  ? Container()
                                  : IconButton(
                                      onPressed: () async {
                                        await enrollmentViewModel
                                            .sendEnrollmentRequest(
                                                course['id']);
                                        final snackBar = SnackBar(
                                          content: Text(enrollmentViewModel
                                                  .hasError
                                              ? 'Failed to send enrollment request'
                                              : 'Enrollment request sent'),
                                        );
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(snackBar);
                                      },
                                      icon: Icon(
                                        Icons.add,
                                        color: Colors.blue,
                                        size: 20,
                                      ),
                                      padding: EdgeInsets.zero,
                                      constraints: BoxConstraints(),
                                    );
                            },
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
