import 'package:flutter/material.dart';
import 'package:motion_tab_bar_v2/motion-tab-bar.dart';
import 'package:motion_tab_bar_v2/motion-tab-controller.dart';

class BottomNavigation extends StatelessWidget {
  final MotionTabBarController controller;
  final int currentIndex;
  final Function(int) onTap;

  BottomNavigation({
    required this.controller,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return MotionTabBar(
      labels: const ["Home", "Search", "Notifications", "Profile"],
      initialSelectedTab: "Home",
      tabIconColor: Colors.grey,
      tabSelectedColor: Colors.blue,
      icons: const [
        Icons.home,
        Icons.search,
        Icons.notifications,
        Icons.person
      ],
      textStyle: const TextStyle(color: Colors.blue),
      onTabItemSelected: onTap,
      controller: controller,
    );
  }
}
