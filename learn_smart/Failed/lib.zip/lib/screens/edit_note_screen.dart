// lib/screens/edit_note_screen.dart
import 'package:flutter/material.dart';
import 'package:learn_smart/view_models/auth_view_model.dart';
import 'package:learn_smart/view_models/note_view_model.dart';
import 'package:provider/provider.dart';
import 'package:get/get.dart';

class EditNoteScreen extends StatefulWidget {
  @override
  _EditNoteScreenState createState() => _EditNoteScreenState();
}

class _EditNoteScreenState extends State<EditNoteScreen> {
  final _formKey = GlobalKey<FormState>();
  String? _title;
  String? _content;
  int? noteId;
  int? moduleId;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    final arguments = Get.arguments;
    if (arguments != null) {
      noteId = arguments['noteId'];
      moduleId = arguments['moduleId'];
      _title = arguments['title'];
      _content = arguments['content'];
    }
  }

  Future<void> _updateNote() async {
    setState(() {
      errorMessage = null;
    });

    if (_formKey.currentState?.validate() ?? false) {
      _formKey.currentState?.save();

      // Access the token using the AuthViewModel provider
      final token = Provider.of<AuthViewModel>(context, listen: false).token;

      // Ensure the token is not null
      if (token == null) {
        setState(() {
          errorMessage = 'Authentication token is missing. Please log in.';
        });
        return;
      }

      final noteViewModel = Provider.of<NoteViewModel>(context, listen: false);
      noteViewModel.updateToken(token);

      try {
        print('Updating note with Title: $_title, Content: $_content');
        bool success = await noteViewModel.updateNote(
            noteId!, moduleId!, _title!, _content!);

        if (success) {
          print('Note updated successfully');
          // Fetch updated notes or update state accordingly if needed
          await noteViewModel.fetchNotes(moduleId!);
          Get.back(); // Navigate back to ModuleDetailScreen
        } else {
          print('Failed to update note');
          setState(() {
            errorMessage = 'Failed to update note. Please try again.';
          });
        }
      } catch (e) {
        print('Error occurred: $e');
        setState(() {
          errorMessage = 'An error occurred: $e';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Note'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              if (errorMessage != null)
                Text(
                  errorMessage!,
                  style: const TextStyle(color: Colors.red),
                ),
              TextFormField(
                initialValue: _title,
                decoration: const InputDecoration(labelText: 'Title'),
                onSaved: (value) => _title = value,
                validator: (value) =>
                    value?.isEmpty ?? true ? 'Please enter a title' : null,
              ),
              TextFormField(
                initialValue: _content,
                decoration: const InputDecoration(labelText: 'Content'),
                onSaved: (value) => _content = value,
                validator: (value) =>
                    value?.isEmpty ?? true ? 'Please enter content' : null,
              ),
              const SizedBox(height: 20),
              Consumer<NoteViewModel>(
                builder: (context, noteViewModel, child) {
                  return noteViewModel.isLoading
                      ? CircularProgressIndicator()
                      : ElevatedButton(
                          onPressed: _updateNote,
                          child: const Text('Update Note'),
                        );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
