import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ModuleViewModel extends ChangeNotifier {
  bool isLoading = false;
  bool hasError = false;
  List<Map<String, dynamic>> modules = [];
  String? token;

  void updateToken(String? newToken) {
    token = newToken;
    notifyListeners();
  }

  Future<void> fetchModuleDetails(int moduleId) async {
    _setLoadingState(true);
    final url = 'http://10.0.2.2:8000/api/modules/$moduleId/';

    try {
      final response = await http.get(
        Uri.parse(url),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        modules = [json.decode(response.body)];
        _setErrorState(false);
      } else {
        _setErrorState(true);
      }
    } catch (error) {
      _setErrorState(true);
    } finally {
      _setLoadingState(false);
    }
  }

  Future<bool> createModule(
      int courseId, String title, String description) async {
    _setLoadingState(true);
    final url = 'http://10.0.2.2:8000/api/modules/';
    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: json.encode({
          'course': courseId,
          'title': title,
          'description': description,
        }),
      );

      if (response.statusCode == 201) {
        await fetchModules(courseId); // Refresh the list of modules
        return true;
      } else {
        _setErrorState(true);
        return false;
      }
    } catch (error) {
      _setErrorState(true);
      return false;
    } finally {
      _setLoadingState(false);
    }
  }

  Future<void> fetchModules(int courseId) async {
    _setLoadingState(true);
    final url = 'http://10.0.2.2:8000/api/modules/?course_id=$courseId';

    try {
      final response = await http.get(
        Uri.parse(url),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        modules = List<Map<String, dynamic>>.from(json.decode(response.body));
        _setErrorState(false);
      } else {
        _setErrorState(true);
      }
    } catch (error) {
      _setErrorState(true);
    } finally {
      _setLoadingState(false);
    }
  }

  Future<bool> updateModule(
      int moduleId, int courseId, String title, String description) async {
    _setLoadingState(true);
    final url = 'http://10.0.2.2:8000/api/modules/$moduleId/';
    try {
      final response = await http.put(
        Uri.parse(url),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: json.encode({
          'course': courseId,
          'title': title,
          'description': description,
        }),
      );

      if (response.statusCode == 200) {
        await fetchModules(courseId); // Refresh the list of modules
        return true;
      } else {
        _setErrorState(true);
        return false;
      }
    } catch (error) {
      _setErrorState(true);
      return false;
    } finally {
      _setLoadingState(false);
    }
  }

  Future<bool> deleteModule(int moduleId, int courseId) async {
    _setLoadingState(true);
    final url = 'http://10.0.2.2:8000/api/modules/$moduleId/';
    try {
      final response = await http.delete(
        Uri.parse(url),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 204) {
        await fetchModules(courseId); // Refresh the list of modules
        return true;
      } else {
        _setErrorState(true);
        return false;
      }
    } catch (error) {
      _setErrorState(true);
      return false;
    } finally {
      _setLoadingState(false);
    }
  }

  void _setLoadingState(bool state) {
    isLoading = state;
    notifyListeners();
  }

  void _setErrorState(bool state) {
    hasError = state;
    notifyListeners();
  }
}
