import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class QuizViewModel extends ChangeNotifier {
  bool isLoading = false;
  bool hasError = false;
  List<Map<String, dynamic>> quizzes = [];
  String? token;
  String? errorMessage;

  void updateToken(String? newToken) {
    token = newToken;
    notifyListeners();
  }

  Future<void> fetchQuizzes(int moduleId) async {
    await _performHttpRequest(
      url: 'http://10.0.2.2:8000/api/modules/$moduleId/quizzes/',
      requestType: 'GET',
      onSuccess: (response) {
        quizzes = List<Map<String, dynamic>>.from(json.decode(response.body));
        _setErrorState(false);
      },
      onError: (error) => _setErrorState(true, error),
    );
  }

  Future<bool> createQuiz(
    int moduleId,
    String title,
    String description,
    String quizType,
    String category,
    List<Map<String, dynamic>> questions,
  ) async {
    final requestData = {
      'title': title,
      'description': description,
      'quiz_type': quizType, // e.g., 'graded'
      'category': category, // e.g., 'MCQ'
      'questions': questions
          .map((question) => {
                'question_text': question['question_text'],
                'option_a': question['option_a'],
                'option_b': question['option_b'],
                'option_c': question['option_c'],
                'option_d': question['option_d'],
                'correct_answer': question['correct_answer'],
              })
          .toList(),
    };

    return await _performHttpRequest(
      url: 'http://10.0.2.2:8000/api/modules/$moduleId/quizzes/',
      requestType: 'POST',
      body: requestData,
      onSuccess: (response) async {
        await fetchQuizzes(moduleId);
        return true;
      },
      onError: (error) {
        _setErrorState(true, error);
        return false;
      },
    );
  }

  Future<bool> updateQuiz(
    int quizId,
    int moduleId,
    String title,
    String description,
    List<Map<String, dynamic>> questions,
  ) async {
    return await _performHttpRequest(
      url: 'http://10.0.2.2:8000/api/modules/$moduleId/quizzes/$quizId/',
      requestType: 'PUT',
      body: {
        'title': title,
        'description': description,
        'questions': questions
            .map((question) => {
                  'question_text': question['question_text'],
                  'option_a': question['option_a'],
                  'option_b': question['option_b'],
                  'option_c': question['option_c'],
                  'option_d': question['option_d'],
                  'correct_answer': question['correct_answer'],
                })
            .toList(),
      },
      onSuccess: (_) async {
        await fetchQuizzes(moduleId);
        return true;
      },
      onError: (error) {
        _setErrorState(true, error);
        return false;
      },
    );
  }

  Future<bool> deleteQuiz(int quizId, int moduleId) async {
    return await _performHttpRequest(
      url: 'http://10.0.2.2:8000/api/modules/$moduleId/quizzes/$quizId/',
      requestType: 'DELETE',
      onSuccess: (_) async {
        await fetchQuizzes(moduleId);
        return true;
      },
      onError: (error) {
        _setErrorState(true, error);
        return false;
      },
    );
  }

  Future<dynamic> _performHttpRequest({
    required String url,
    required String requestType,
    Map<String, dynamic>? body,
    required Function(http.Response) onSuccess,
    required Function(String) onError,
  }) async {
    _setLoadingState(true);
    try {
      final response = await _httpRequest(url, requestType, body);
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return onSuccess(response);
      } else if (response.statusCode == 401) {
        onError('Unauthorized: Invalid or expired token.');
        return false;
      } else {
        onError('Failed with status code: ${response.statusCode}');
        return false;
      }
    } catch (error) {
      onError('An error occurred: $error');
      return false;
    } finally {
      _setLoadingState(false);
    }
  }

  Future<http.Response> _httpRequest(
    String url,
    String requestType,
    Map<String, dynamic>? body,
  ) async {
    final headers = {
      'Authorization': 'Bearer $token',
      'Content-Type': 'application/json',
    };

    switch (requestType) {
      case 'GET':
        return await http.get(Uri.parse(url), headers: headers);
      case 'POST':
        return await http.post(Uri.parse(url),
            headers: headers, body: json.encode(body));
      case 'PUT':
        return await http.put(Uri.parse(url),
            headers: headers, body: json.encode(body));
      case 'DELETE':
        return await http.delete(Uri.parse(url), headers: headers);
      default:
        throw Exception('Invalid request type');
    }
  }

  void _setLoadingState(bool state) {
    isLoading = state;
    notifyListeners();
  }

  void _setErrorState(bool state, [String? message]) {
    hasError = state;
    errorMessage = message;
    notifyListeners();
  }
}
