import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AuthViewModel extends ChangeNotifier {
  String? _token;
  String? _role;
  int? _userId;
  String? _username;
  String? _profileImage; // Add this line

  String? get token => _token;
  String? get role => _role;
  int? get userId => _userId;
  String? get username => _username;
  String? get profileImage => _profileImage; // Add this getter

  Future<void> login(String username, String password) async {
    final response = await http.post(
      Uri.parse('http://10.0.2.2:8000/api/token/'),
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'username': username,
        'password': password,
      }),
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      _token = data['access'];
      notifyListeners();
      await fetchUserRoleAndId(); // Fetch user details after login
      Get.toNamed('/dashboard');
    } else {
      throw Exception('Failed to login');
    }
  }

  Future<void> register(
    String username,
    String email,
    String password,
    String firstName,
    String lastName,
    String role,
  ) async {
    final response = await http.post(
      Uri.parse('http://10.0.2.2:8000/api/users/register/'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, String>{
        'username': username,
        'email': email,
        'password': password,
        'first_name': firstName,
        'last_name': lastName,
        'role': role,
      }),
    );

    if (response.statusCode == 201) {
      Get.toNamed('/login');
    } else {
      throw Exception('Failed to register');
    }
  }

  Future<void> fetchUserRoleAndId() async {
    final response = await http.get(
      Uri.parse(
          'http://10.0.2.2:8000/api/users/user/'), // Ensure this endpoint returns user details including role, ID, and profile image
      headers: {
        'Authorization': 'Bearer $_token',
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      _role = data['role'];
      _userId = data['id'];
      _username = data['username'];
      _profileImage =
          data['profile_image']; // Update this line to match your API response
      notifyListeners();
    } else {
      throw Exception('Failed to fetch user role and ID');
    }
  }

  void logout() {
    _token = null;
    _role = null;
    _userId = null;
    _username = null;
    _profileImage = null; // Clear the profile image
    notifyListeners();
  }
}
