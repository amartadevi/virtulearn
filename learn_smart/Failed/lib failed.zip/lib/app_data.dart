// lib/app_data.dart
import 'package:flutter/material.dart';

class AppData extends ChangeNotifier {
  String? _userToken;
  String? _userRole;
  int? _courseId;

  String? get userToken => _userToken;
  String? get userRole => _userRole;
  int? get courseId => _courseId;

  // Set user token
  void setUserToken(String token) {
    _userToken = token;
    notifyListeners();
  }

  // Set user role
  void setUserRole(String role) {
    _userRole = role;
    notifyListeners();
  }

  // Set course ID
  void setCourseId(int id) {
    _courseId = id;
    notifyListeners();
  }

  // Clear all data
  void clearData() {
    _userToken = null;
    _userRole = null;
    _courseId = null;
    notifyListeners();
  }
}
