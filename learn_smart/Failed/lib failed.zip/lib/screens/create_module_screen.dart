// lib/screens/create_module_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:learn_smart/view_models/auth_view_model.dart';
import 'package:learn_smart/view_models/module_view_model.dart';
import 'package:provider/provider.dart';

class CreateModuleScreen extends StatefulWidget {
  @override
  _CreateModuleScreenState createState() => _CreateModuleScreenState();
}

class _CreateModuleScreenState extends State<CreateModuleScreen> {
  final _formKey = GlobalKey<FormState>();
  String? _title;
  String? _description;
  String? errorMessage;

  Future<void> _createModule(ModuleViewModel moduleViewModel) async {
    setState(() {
      errorMessage = null;
    });

    if (_formKey.currentState?.validate() ?? false) {
      _formKey.currentState?.save();

      // Retrieve courseId and token
      final courseId = Get.arguments['courseId'];
      final token = Provider.of<AuthViewModel>(context, listen: false).token;

      if (courseId == null || token == null) {
        setState(() {
          errorMessage = 'Course ID or token is missing.';
        });
        return;
      }

      moduleViewModel.updateToken(token);

      try {
        bool success = await moduleViewModel.createModule(
            courseId, _title!, _description!);

        if (success) {
          await moduleViewModel.fetchModules(courseId);
          Get.back(); // Navigate back to CourseDetailScreen
        } else {
          setState(() {
            errorMessage = 'Failed to create module. Please try again.';
          });
        }
      } catch (e) {
        setState(() {
          errorMessage = 'An error occurred: $e';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ModuleViewModel(),
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Create Module'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Consumer<ModuleViewModel>(
            builder: (context, moduleViewModel, child) {
              return Form(
                key: _formKey,
                child: Column(
                  children: [
                    if (errorMessage != null)
                      Text(
                        errorMessage!,
                        style: const TextStyle(color: Colors.red),
                      ),
                    TextFormField(
                      decoration: const InputDecoration(labelText: 'Title'),
                      onSaved: (value) => _title = value,
                      validator: (value) => value?.isEmpty ?? true
                          ? 'Please enter a title'
                          : null,
                    ),
                    TextFormField(
                      decoration:
                          const InputDecoration(labelText: 'Description'),
                      onSaved: (value) => _description = value,
                      validator: (value) => value?.isEmpty ?? true
                          ? 'Please enter a description'
                          : null,
                    ),
                    const SizedBox(height: 20),
                    moduleViewModel.isLoading
                        ? CircularProgressIndicator()
                        : ElevatedButton(
                            onPressed: () => _createModule(moduleViewModel),
                            child: const Text('Create Module'),
                          ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
