import 'package:flutter/material.dart';
import 'package:learn_smart/view_models/auth_view_model.dart';
import 'package:learn_smart/view_models/quiz_view_model.dart';
import 'package:provider/provider.dart';
import 'package:get/get.dart';

class CreateQuizScreen extends StatefulWidget {
  @override
  _CreateQuizScreenState createState() => _CreateQuizScreenState();
}

class _CreateQuizScreenState extends State<CreateQuizScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _quizTypeController = TextEditingController();
  final _categoryController = TextEditingController();
  List<Map<String, dynamic>> _questions = [];
  String? errorMessage;

  int? moduleId;

  @override
  void initState() {
    super.initState();
    final arguments = Get.arguments;
    if (arguments != null) {
      moduleId = arguments['moduleId'];
    }
  }

  Future<void> _createQuiz(QuizViewModel quizViewModel) async {
    if (_formKey.currentState?.validate() ?? false) {
      _formKey.currentState?.save();
      final token = Provider.of<AuthViewModel>(context, listen: false).token;

      // Debugging: Print the token to the console
      print("Token: $token");

      quizViewModel.updateToken(token);

      try {
        bool success = await quizViewModel.createQuiz(
          moduleId!,
          _titleController.text,
          _descriptionController.text,
          _quizTypeController.text,
          _categoryController.text,
          _questions,
        );
        if (success) {
          Get.back();
        } else {
          _showError('Failed to create quiz. Please try again.');
        }
      } catch (e) {
        _showError('An error occurred: $e');
        // Debugging: Print the exception
        print("Error during quiz creation: $e");
      }
    }
  }

  void _showError(String message) {
    setState(() {
      errorMessage = message;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => QuizViewModel(),
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Create Quiz'),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Consumer<QuizViewModel>(
              builder: (context, quizViewModel, child) {
                return Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      _buildTextInput(_titleController, 'Quiz Title'),
                      _buildTextInput(
                          _descriptionController, 'Quiz Description'),
                      _buildTextInput(_quizTypeController, 'Quiz Type'),
                      _buildTextInput(_categoryController, 'Category'),
                      const SizedBox(height: 20),
                      if (errorMessage != null)
                        Text(errorMessage!,
                            style: const TextStyle(color: Colors.red)),
                      ..._buildQuestionAnswerFields(),
                      const SizedBox(height: 20),
                      quizViewModel.isLoading
                          ? CircularProgressIndicator()
                          : ElevatedButton(
                              onPressed: () => _createQuiz(quizViewModel),
                              child: const Text('Create Quiz'),
                            ),
                      ElevatedButton(
                        onPressed: () {
                          setState(() {
                            _questions.add({
                              'question_text': '',
                              'option_a': '',
                              'option_b': '',
                              'option_c': '',
                              'option_d': '',
                              'correct_answer': ''
                            });
                          });
                        },
                        child: const Text('Add Question'),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextInput(TextEditingController controller, String label) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(labelText: label),
      validator: (value) =>
          value?.isEmpty ?? true ? 'Please enter $label.toLowerCase()' : null,
    );
  }

  List<Widget> _buildQuestionAnswerFields() {
    List<Widget> fields = [];
    for (int i = 0; i < _questions.length; i++) {
      fields.add(
        Column(
          key: UniqueKey(),
          children: [
            _buildTextInputField('Question ${i + 1}', 'question_text', i),
            _buildTextInputField('Option A', 'option_a', i),
            _buildTextInputField('Option B', 'option_b', i),
            _buildTextInputField('Option C', 'option_c', i),
            _buildTextInputField('Option D', 'option_d', i),
            _buildTextInputField('Correct Answer', 'correct_answer', i),
          ],
        ),
      );
    }
    return fields;
  }

  Widget _buildTextInputField(String label, String key, int questionIndex) {
    return TextFormField(
      decoration: InputDecoration(labelText: label),
      onSaved: (value) => _questions[questionIndex][key] = value ?? '',
      validator: (value) =>
          value?.isEmpty ?? true ? 'Please enter $label.toLowerCase()' : null,
    );
  }
}
