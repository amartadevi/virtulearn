import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:learn_smart/screens/app_bar.dart';
import 'package:learn_smart/view_models/enrollment_view_model.dart';
import 'package:learn_smart/view_models/module_view_model.dart';
import 'package:learn_smart/view_models/auth_view_model.dart';
import 'package:learn_smart/view_models/course_view_model.dart';
import 'package:provider/provider.dart';

class CourseDetailScreen extends StatefulWidget {
  final int courseId;

  CourseDetailScreen({Key? key, required this.courseId}) : super(key: key);

  @override
  _CourseDetailScreenState createState() => _CourseDetailScreenState();
}

class _CourseDetailScreenState extends State<CourseDetailScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final courseViewModel =
          Provider.of<CourseViewModel>(context, listen: false);
      final moduleViewModel =
          Provider.of<ModuleViewModel>(context, listen: false);
      final authViewModel = Provider.of<AuthViewModel>(context, listen: false);
      final enrollmentViewModel =
          Provider.of<EnrollmentViewModel>(context, listen: false);

      courseViewModel.updateToken(authViewModel.token);
      moduleViewModel.updateToken(authViewModel.token);
      enrollmentViewModel.updateToken(authViewModel.token);

      if (authViewModel.token != null) {
        courseViewModel.fetchCourseDetail(widget.courseId);
        moduleViewModel.fetchModules(widget.courseId);
        enrollmentViewModel.fetchEnrollmentRequests('student');
      }
    });
  }

  bool _isEnrolled(EnrollmentViewModel enrollmentViewModel, int courseId) {
    return enrollmentViewModel.enrollmentRequests.any(
      (request) =>
          request['course'] == courseId && request['status'] == 'approved',
    );
  }

  @override
  Widget build(BuildContext context) {
    final authViewModel = Provider.of<AuthViewModel>(context);
    final courseViewModel = Provider.of<CourseViewModel>(context);
    final moduleViewModel = Provider.of<ModuleViewModel>(context);
    final enrollmentViewModel = Provider.of<EnrollmentViewModel>(context);

    return Scaffold(
      appBar: CustomAppBar(
        title: 'Course Detail',
        actions: [
          if (authViewModel.role != 'student')
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'edit') {
                  _showEditCourseDialog(context);
                } else if (value == 'delete') {
                  _showDeleteCourseConfirmation(context);
                }
              },
              itemBuilder: (context) => [
                const PopupMenuItem(
                  value: 'edit',
                  child: Text('Edit'),
                ),
                const PopupMenuItem(
                  value: 'delete',
                  child: Text('Delete'),
                ),
              ],
              icon: const Icon(Icons.more_vert),
            ),
        ],
      ),
      body: courseViewModel.isLoading
          ? const Center(child: CircularProgressIndicator())
          : courseViewModel.hasError
              ? Center(
                  child: Text(courseViewModel.errorMessage ??
                      'Error loading course details'))
              : Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          courseViewModel.courseDetails['name'] ?? '',
                          style: Theme.of(context)
                              .textTheme
                              .headlineLarge
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          courseViewModel.courseDetails['description'] ?? '',
                          style: Theme.of(context).textTheme.bodyLarge,
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'Created by: ${courseViewModel.courseDetails['createdByUsername'] ?? 'Not Found!'}',
                          style: Theme.of(context).textTheme.bodyLarge,
                        ),
                        const SizedBox(height: 20),
                        if (authViewModel.role != 'student')
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Students Enrolled:',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodySmall
                                    ?.copyWith(fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 10),
                              if (courseViewModel.courseDetails['students']
                                  is List)
                                ListView.builder(
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  itemCount:
                                      (courseViewModel.courseDetails['students']
                                              as List<dynamic>)
                                          .length,
                                  itemBuilder: (context, index) {
                                    final studentData = (courseViewModel
                                            .courseDetails['students']
                                        as List<dynamic>)[index];

                                    if (studentData is Map<String, dynamic>) {
                                      return ListTile(
                                        title:
                                            Text(studentData['username'] ?? ''),
                                      );
                                    } else {
                                      return const ListTile(
                                        title: Text('Invalid student data'),
                                      );
                                    }
                                  },
                                )
                              else
                                const Text('No students enrolled'),
                            ],
                          ),
                        const SizedBox(height: 20),
                        Text(
                          'Modules',
                          style: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 10),
                        ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: moduleViewModel.modules.length,
                          itemBuilder: (context, index) {
                            final module = moduleViewModel.modules[index];
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 10.0),
                              child: ModuleCard(
                                module: Module(
                                  title: module['title'] ?? '',
                                  author: module['description'] ?? '',
                                  imagePath:
                                      'assets/icons/flutter.jpg', // Using asset image for now
                                ),
                                onEdit: authViewModel.role != 'student'
                                    ? () {
                                        _showEditModuleDialog(context, module);
                                      }
                                    : null,
                                onDelete: authViewModel.role != 'student'
                                    ? () async {
                                        await moduleViewModel.deleteModule(
                                            module['id'], widget.courseId);
                                        Navigator.of(context).pop();
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          const SnackBar(
                                              content: Text('Module deleted')),
                                        );
                                      }
                                    : null,
                                onTap: () {
                                  Get.toNamed('/module-detail', arguments: {
                                    'moduleId': module['id'],
                                    'title': module['title'],
                                  });
                                },
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
      bottomNavigationBar: (authViewModel.role == 'student' &&
              !_isEnrolled(enrollmentViewModel, widget.courseId))
          ? Padding(
              padding: const EdgeInsets.all(16.0),
              child: SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: () {
                    _showEnrollDialog(context, widget.courseId);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xff0095FF),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                  ),
                  child: const Text(
                    'Enroll',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            )
          : null,
    );
  }

  void _showEditModuleDialog(BuildContext context, dynamic module) {
    final _formKey = GlobalKey<FormState>();
    String? _title = module['title'];
    String? _description = module['description'];

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Edit Module'),
          content: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  initialValue: _title,
                  decoration: const InputDecoration(labelText: 'Title'),
                  onSaved: (value) {
                    _title = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a title';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  initialValue: _description,
                  decoration: const InputDecoration(labelText: 'Description'),
                  onSaved: (value) {
                    _description = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a description';
                    }
                    return null;
                  },
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (_formKey.currentState!.validate()) {
                  _formKey.currentState!.save();
                  final moduleViewModel =
                      Provider.of<ModuleViewModel>(context, listen: false);
                  bool success = await moduleViewModel.updateModule(
                      module['id'], widget.courseId, _title!, _description!);
                  if (success) {
                    Navigator.of(context).pop();
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Module updated successfully'),
                      ),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Failed to update module'),
                      ),
                    );
                  }
                }
              },
              child: const Text('Update'),
            ),
          ],
        );
      },
    );
  }

  void _showEditCourseDialog(BuildContext context) {
    final _formKey = GlobalKey<FormState>();
    String? _name = Provider.of<CourseViewModel>(context, listen: false)
        .courseDetails['name'];
    String? _description = Provider.of<CourseViewModel>(context, listen: false)
        .courseDetails['description'];

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Edit Course'),
          content: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  initialValue: _name,
                  decoration: const InputDecoration(labelText: 'Name'),
                  onSaved: (value) {
                    _name = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a name';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  initialValue: _description,
                  decoration: const InputDecoration(labelText: 'Description'),
                  onSaved: (value) {
                    _description = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a description';
                    }
                    return null;
                  },
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (_formKey.currentState!.validate()) {
                  _formKey.currentState!.save();
                  final courseViewModel =
                      Provider.of<CourseViewModel>(context, listen: false);
                  await courseViewModel.updateCourse(
                      widget.courseId, _name!, _description!);
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Course updated successfully'),
                    ),
                  );
                }
              },
              child: const Text('Update'),
            ),
          ],
        );
      },
    );
  }

  void _showDeleteCourseConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Delete Course'),
          content: Text(
              'Are you sure you want to delete the course "${Provider.of<CourseViewModel>(context, listen: false).courseDetails['name']}"?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                final courseViewModel =
                    Provider.of<CourseViewModel>(context, listen: false);
                await courseViewModel.deleteCourse(widget.courseId);
                Navigator.of(context).pop();
                Get.back(); // Navigate back
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Course deleted')),
                );
              },
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );
  }

  void _showEnrollDialog(BuildContext context, int courseId) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Enroll in Course'),
          content:
              const Text('Are you sure you want to enroll in this course?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                final enrollmentViewModel =
                    Provider.of<EnrollmentViewModel>(context, listen: false);
                await enrollmentViewModel.sendEnrollmentRequest(courseId);
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Enrollment request sent')),
                );
              },
              child: const Text('Enroll'),
            ),
          ],
        );
      },
    );
  }
}

class ModuleCard extends StatelessWidget {
  final Module module;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;
  final VoidCallback? onTap;

  ModuleCard({
    required this.module,
    this.onEdit,
    this.onDelete,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        elevation: 5,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Row(
            children: [
              Image.asset(
                module.imagePath,
                width: 50,
                height: 50,
              ),
              const SizedBox(width: 20),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      module.title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      module.author,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
              if (onEdit != null)
                IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: onEdit,
                ),
              if (onDelete != null)
                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: onDelete,
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class Module {
  final String title;
  final String author;
  final String imagePath;

  Module({
    required this.title,
    required this.author,
    required this.imagePath,
  });
}
