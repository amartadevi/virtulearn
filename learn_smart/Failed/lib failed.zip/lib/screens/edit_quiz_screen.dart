import 'package:flutter/material.dart';
import 'package:learn_smart/view_models/auth_view_model.dart';
import 'package:learn_smart/view_models/quiz_view_model.dart';
import 'package:provider/provider.dart';
import 'package:get/get.dart';

class EditQuizScreen extends StatefulWidget {
  @override
  _EditQuizScreenState createState() => _EditQuizScreenState();
}

class _EditQuizScreenState extends State<EditQuizScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  List<Map<String, dynamic>> _questions = [];
  int? quizId;
  int? moduleId;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    final arguments = Get.arguments;
    if (arguments != null) {
      quizId = arguments['quizId'];
      moduleId = arguments['moduleId'];
      _titleController.text = arguments['title'] ?? '';
      _descriptionController.text = arguments['description'] ?? '';
      _questions =
          List<Map<String, dynamic>>.from(arguments['questions'] ?? []);
    }
  }

  Future<void> _updateQuiz(QuizViewModel quizViewModel) async {
    setState(() {
      errorMessage = null;
    });

    if (_formKey.currentState?.validate() ?? false) {
      _formKey.currentState?.save();

      final token = Provider.of<AuthViewModel>(context, listen: false).token;

      quizViewModel.updateToken(token);

      try {
        print('Updating quiz with Questions: $_questions');
        bool success = await quizViewModel.updateQuiz(
          quizId!,
          moduleId!,
          _titleController.text,
          _descriptionController.text,
          _questions,
        );

        if (success) {
          print('Quiz updated successfully');
          await quizViewModel.fetchQuizzes(moduleId!);
          Get.back(); // Navigate back to ModuleDetailScreen
        } else {
          print('Failed to update quiz');
          setState(() {
            errorMessage = 'Failed to update quiz. Please try again.';
          });
        }
      } catch (e) {
        print('Error occurred: $e');
        setState(() {
          errorMessage = 'An error occurred: $e';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => QuizViewModel(),
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Edit Quiz'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Consumer<QuizViewModel>(
            builder: (context, quizViewModel, child) {
              return Form(
                key: _formKey,
                child: Column(
                  children: [
                    TextFormField(
                      controller: _titleController,
                      decoration:
                          const InputDecoration(labelText: 'Quiz Title'),
                      validator: (value) => value?.isEmpty ?? true
                          ? 'Please enter a title'
                          : null,
                    ),
                    TextFormField(
                      controller: _descriptionController,
                      decoration:
                          const InputDecoration(labelText: 'Quiz Description'),
                      validator: (value) => value?.isEmpty ?? true
                          ? 'Please enter a description'
                          : null,
                    ),
                    const SizedBox(height: 20),
                    if (errorMessage != null)
                      Text(
                        errorMessage!,
                        style: const TextStyle(color: Colors.red),
                      ),
                    ..._buildQuestionAnswerFields(),
                    const SizedBox(height: 20),
                    quizViewModel.isLoading
                        ? CircularProgressIndicator()
                        : ElevatedButton(
                            onPressed: () => _updateQuiz(quizViewModel),
                            child: const Text('Update Quiz'),
                          ),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _questions.add({
                            'question_text': '',
                            'option_a': '',
                            'option_b': '',
                            'option_c': '',
                            'option_d': '',
                            'correct_answer': ''
                          });
                        });
                      },
                      child: const Text('Add Question'),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  List<Widget> _buildQuestionAnswerFields() {
    List<Widget> fields = [];
    for (int i = 0; i < _questions.length; i++) {
      fields.add(
        Column(
          key: UniqueKey(),
          children: [
            TextFormField(
              decoration: InputDecoration(labelText: 'Question ${i + 1}'),
              initialValue: _questions[i]['question_text'],
              onSaved: (value) => _questions[i]['question_text'] = value ?? '',
              validator: (value) =>
                  value?.isEmpty ?? true ? 'Please enter a question' : null,
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Option A'),
              initialValue: _questions[i]['option_a'],
              onSaved: (value) => _questions[i]['option_a'] = value ?? '',
              validator: (value) =>
                  value?.isEmpty ?? true ? 'Please enter option A' : null,
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Option B'),
              initialValue: _questions[i]['option_b'],
              onSaved: (value) => _questions[i]['option_b'] = value ?? '',
              validator: (value) =>
                  value?.isEmpty ?? true ? 'Please enter option B' : null,
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Option C'),
              initialValue: _questions[i]['option_c'],
              onSaved: (value) => _questions[i]['option_c'] = value ?? '',
              validator: (value) =>
                  value?.isEmpty ?? true ? 'Please enter option C' : null,
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Option D'),
              initialValue: _questions[i]['option_d'],
              onSaved: (value) => _questions[i]['option_d'] = value ?? '',
              validator: (value) =>
                  value?.isEmpty ?? true ? 'Please enter option D' : null,
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Correct Answer'),
              initialValue: _questions[i]['correct_answer'],
              onSaved: (value) => _questions[i]['correct_answer'] = value ?? '',
              validator: (value) => value?.isEmpty ?? true
                  ? 'Please enter the correct answer'
                  : null,
            ),
          ],
        ),
      );
    }
    return fields;
  }
}
