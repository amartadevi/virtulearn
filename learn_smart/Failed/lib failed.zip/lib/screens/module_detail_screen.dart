import 'package:flutter/material.dart';
import 'package:learn_smart/screens/app_bar.dart';
import 'package:provider/provider.dart';
import '../view_models/module_view_model.dart';
import '../view_models/note_view_model.dart';
import '../view_models/quiz_view_model.dart';
import '../view_models/auth_view_model.dart';

class ModuleDetailScreen extends StatefulWidget {
  final int moduleId;

  ModuleDetailScreen({Key? key, required this.moduleId}) : super(key: key);

  @override
  _ModuleDetailScreenState createState() => _ModuleDetailScreenState();
}

class _ModuleDetailScreenState extends State<ModuleDetailScreen>
    with SingleTickerProviderStateMixin {
  String moduleTitle = "Loading...";
  String moduleDescription = "Loading description...";
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadModuleDetails();
    });
  }

  void _loadModuleDetails() async {
    final moduleViewModel =
        Provider.of<ModuleViewModel>(context, listen: false);
    final noteViewModel = Provider.of<NoteViewModel>(context, listen: false);
    final quizViewModel = Provider.of<QuizViewModel>(context, listen: false);
    final authViewModel = Provider.of<AuthViewModel>(context, listen: false);

    moduleViewModel.updateToken(authViewModel.token);
    noteViewModel.updateToken(authViewModel.token);
    quizViewModel.updateToken(authViewModel.token);

    await moduleViewModel.fetchModuleDetails(widget.moduleId);

    if (moduleViewModel.modules.isNotEmpty) {
      setState(() {
        moduleTitle = moduleViewModel.modules[0]['title'] ?? "Module Title";
        moduleDescription =
            moduleViewModel.modules[0]['description'] ?? "Module Description";
      });

      noteViewModel.fetchNotes(widget.moduleId);
      quizViewModel.fetchQuizzes(widget.moduleId);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: moduleTitle),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildModuleHeader(),
          _buildTabs(),
        ],
      ),
      floatingActionButton: _buildFloatingActionButton(),
    );
  }

  Widget _buildModuleHeader() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            moduleTitle,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            moduleDescription,
            style: const TextStyle(fontSize: 16, color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _buildTabs() {
    return Expanded(
      child: DefaultTabController(
        length: 2,
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16.0),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(50),
                color: Colors.grey[200],
              ),
              child: TabBar(
                controller: _tabController,
                labelColor: Colors.blue,
                unselectedLabelColor: Colors.black,
                indicator: BoxDecoration(),
                tabs: const [
                  Tab(text: "Notes"),
                  Tab(text: "Quizzes"),
                ],
              ),
            ),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildNotesSection(),
                  _buildQuizzesSection(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNotesSection() {
    return Consumer<NoteViewModel>(
      builder: (context, noteViewModel, child) {
        if (noteViewModel.isLoading) {
          return const Center(child: CircularProgressIndicator());
        } else if (noteViewModel.hasError) {
          return _buildErrorMessage(
              'Error loading notes: ${noteViewModel.errorMessage}');
        } else {
          return _buildNoteList(noteViewModel);
        }
      },
    );
  }

  Widget _buildQuizzesSection() {
    return Consumer<QuizViewModel>(
      builder: (context, quizViewModel, child) {
        if (quizViewModel.isLoading) {
          return const Center(child: CircularProgressIndicator());
        } else if (quizViewModel.hasError) {
          return _buildErrorMessage(
              'Error loading quizzes: ${quizViewModel.errorMessage}');
        } else {
          return _buildQuizList(quizViewModel);
        }
      },
    );
  }

  Widget _buildErrorMessage(String message) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Center(child: Text(message)),
    );
  }

  Widget _buildNoteList(NoteViewModel noteViewModel) {
    return ListView.builder(
      padding: EdgeInsets.all(8.0),
      itemCount: noteViewModel.notes.length,
      itemBuilder: (context, index) {
        final note = noteViewModel.notes[index];
        return ListTile(
          leading: CircleAvatar(
            backgroundColor: Colors.purple[100],
            child: Icon(Icons.note, color: Colors.purple),
          ),
          title: Text(note['title']),
          subtitle: Text(note['content']),
        );
      },
    );
  }

  Widget _buildQuizList(QuizViewModel quizViewModel) {
    return ListView.builder(
      padding: EdgeInsets.all(8.0),
      itemCount: quizViewModel.quizzes.length,
      itemBuilder: (context, index) {
        final quiz = quizViewModel.quizzes[index];
        return ListTile(
          leading: CircleAvatar(
            backgroundColor: Colors.blue[100],
            child: Icon(Icons.quiz, color: Colors.blue),
          ),
          title: Text(quiz['title']),
          subtitle: Text(quiz['description']),
        );
      },
    );
  }

  Widget _buildFloatingActionButton() {
    return Consumer<AuthViewModel>(
      builder: (context, authViewModel, child) {
        if (authViewModel.role == 'student') {
          return Container();
        }

        return FloatingActionButton(
          onPressed: () {
            if (_tabController.index == 0) {
              _showCreateNoteDialog(context);
            } else {
              _showCreateQuizDialog(context);
            }
          },
          backgroundColor: Colors.blue,
          child: Icon(Icons.add),
        );
      },
    );
  }

  void _showCreateNoteDialog(BuildContext context) {
    final _formKey = GlobalKey<FormState>();
    String? _title;
    String? _content;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Create Note'),
          content: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  decoration: InputDecoration(labelText: 'Title'),
                  onSaved: (value) {
                    _title = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a title';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  decoration: InputDecoration(labelText: 'Content'),
                  onSaved: (value) {
                    _content = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter content';
                    }
                    return null;
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (_formKey.currentState!.validate()) {
                  _formKey.currentState!.save();
                  final noteViewModel =
                      Provider.of<NoteViewModel>(context, listen: false);
                  await noteViewModel.createNote(
                      widget.moduleId, _title!, _content!);
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Note created successfully')),
                  );
                }
              },
              child: Text('Create'),
            ),
          ],
        );
      },
    );
  }

  void _showCreateQuizDialog(BuildContext context) {
    final _formKey = GlobalKey<FormState>();
    String? _title;
    String? _description;
    String? _quizType;
    String? _category;
    List<Map<String, dynamic>> questions = [];

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Create Quiz'),
          content: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  decoration: InputDecoration(labelText: 'Title'),
                  onSaved: (value) {
                    _title = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a title';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  decoration: InputDecoration(labelText: 'Description'),
                  onSaved: (value) {
                    _description = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a description';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  decoration: InputDecoration(labelText: 'Quiz Type'),
                  onSaved: (value) {
                    _quizType = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter the quiz type';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  decoration: InputDecoration(labelText: 'Category'),
                  onSaved: (value) {
                    _category = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter the quiz category';
                    }
                    return null;
                  },
                ),
                // Add fields for quiz questions here if needed.
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (_formKey.currentState!.validate()) {
                  _formKey.currentState!.save();
                  final quizViewModel =
                      Provider.of<QuizViewModel>(context, listen: false);
                  await quizViewModel.createQuiz(
                    widget.moduleId,
                    _title!,
                    _description!,
                    _quizType!,
                    _category!,
                    questions,
                  );
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Quiz created successfully')),
                  );
                }
              },
              child: Text('Create'),
            ),
          ],
        );
      },
    );
  }
}
