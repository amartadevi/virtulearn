import 'package:flutter/material.dart';
import 'package:learn_smart/view_models/auth_view_model.dart';
import 'package:learn_smart/view_models/note_view_model.dart';
import 'package:provider/provider.dart';
import 'package:get/get.dart';

class CreateNoteScreen extends StatefulWidget {
  @override
  _CreateNoteScreenState createState() => _CreateNoteScreenState();
}

class _CreateNoteScreenState extends State<CreateNoteScreen> {
  final _formKey = GlobalKey<FormState>();
  String? _title;
  String? _content;
  String? errorMessage;

  int? moduleId;

  @override
  void initState() {
    super.initState();
    final arguments = Get.arguments;
    if (arguments != null) {
      moduleId = arguments['moduleId'];
    }
  }

  Future<void> _createNote(NoteViewModel noteViewModel) async {
    setState(() {
      errorMessage = null;
    });

    if (_formKey.currentState?.validate() ?? false) {
      _formKey.currentState?.save();

      final token = Provider.of<AuthViewModel>(context, listen: false).token;

      if (moduleId == null || token == null) {
        setState(() {
          errorMessage = 'Module ID or token is missing.';
        });
        return;
      }

      noteViewModel.updateToken(token);

      try {
        print('Creating note with Title: $_title, Content: $_content');
        bool success =
            await noteViewModel.createNote(moduleId!, _title!, _content!);

        if (success) {
          print('Note created successfully');
          await noteViewModel
              .fetchNotes(moduleId!); // Refresh the list of notes
          Get.back(); // Navigate back to ModuleDetailScreen
        } else {
          print('Failed to create note');
          setState(() {
            errorMessage = 'Failed to create note. Please try again.';
          });
        }
      } catch (e) {
        print('Error occurred: $e');
        setState(() {
          errorMessage = 'An error occurred: $e';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => NoteViewModel(),
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Create Note'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Consumer<NoteViewModel>(
            builder: (context, noteViewModel, child) {
              return Form(
                key: _formKey,
                child: Column(
                  children: [
                    if (errorMessage != null)
                      Text(
                        errorMessage!,
                        style: const TextStyle(color: Colors.red),
                      ),
                    TextFormField(
                      decoration: const InputDecoration(labelText: 'Title'),
                      onSaved: (value) => _title = value,
                      validator: (value) => value?.isEmpty ?? true
                          ? 'Please enter a title'
                          : null,
                    ),
                    TextFormField(
                      decoration: const InputDecoration(labelText: 'Content'),
                      onSaved: (value) => _content = value,
                      validator: (value) => value?.isEmpty ?? true
                          ? 'Please enter content'
                          : null,
                    ),
                    const SizedBox(height: 20),
                    noteViewModel.isLoading
                        ? CircularProgressIndicator()
                        : ElevatedButton(
                            onPressed: () => _createNote(noteViewModel),
                            child: const Text('Create Note'),
                          ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
