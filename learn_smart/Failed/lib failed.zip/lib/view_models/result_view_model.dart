import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ResultViewModel extends ChangeNotifier {
  bool isLoading = false;
  bool hasError = false;
  List<Map<String, dynamic>> results = [];
  String? token;
  String? errorMessage;

  void updateToken(String? newToken) {
    token = newToken;
    print("Token updated: $token"); // Debugging
    notifyListeners();
  }

  Future<void> fetchResults(int quizId, int moduleId) async {
    print(
        "Fetching results for quizId: $quizId, moduleId: $moduleId"); // Debugging
    await _performHttpRequest(
      url:
          'http://10.0.2.2:8000/api/modules/$moduleId/quizzes/$quizId/results/',
      requestType: 'GET',
      onSuccess: (response) {
        print("Response: ${response.body}"); // Debugging
        results = List<Map<String, dynamic>>.from(json.decode(response.body));
        _setErrorState(false);
      },
      onError: (error) {
        print("Error occurred: $error"); // Debugging
        _setErrorState(true, error);
      },
    );
  }

  Future<dynamic> _performHttpRequest({
    required String url,
    required String requestType,
    Map<String, dynamic>? body,
    required Function(http.Response) onSuccess,
    required Function(String) onError,
  }) async {
    _setLoadingState(true);
    try {
      final response = await _httpRequest(url, requestType, body);
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return onSuccess(response);
      } else if (response.statusCode == 401) {
        onError('Unauthorized: Invalid or expired token.');
        return false;
      } else {
        onError('Failed with status code: ${response.statusCode}');
        return false;
      }
    } catch (error) {
      onError('An error occurred: $error');
      return false;
    } finally {
      _setLoadingState(false);
    }
  }

  Future<http.Response> _httpRequest(
      String url, String requestType, Map<String, dynamic>? body) async {
    final headers = {
      'Authorization': 'Bearer $token',
      'Content-Type': 'application/json',
    };

    switch (requestType) {
      case 'GET':
        return await http.get(Uri.parse(url), headers: headers);
      default:
        throw Exception('Invalid request type');
    }
  }

  void _setLoadingState(bool state) {
    isLoading = state;
    notifyListeners();
  }

  void _setErrorState(bool state, [String? message]) {
    hasError = state;
    errorMessage = message;
    notifyListeners();
  }
}
