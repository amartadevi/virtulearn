import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class EnrollmentViewModel extends ChangeNotifier {
  String? _token;
  bool _isLoading = false;
  bool _hasError = false;
  List<dynamic> _enrollmentRequests = [];

  bool get isLoading => _isLoading;
  bool get hasError => _hasError;
  List<dynamic> get enrollmentRequests => _enrollmentRequests;

  void updateToken(String? token) {
    _token = token;
    notifyListeners();
  }

  Future<void> sendEnrollmentRequest(int courseId) async {
    _isLoading = true;
    _hasError = false;
    notifyListeners();

    final response = await http.post(
      Uri.parse('http://10.0.2.2:8000/api/enrollment-requests/create/'),
      headers: {
        'Authorization': 'Bearer $_token',
        'Content-Type': 'application/json',
      },
      body: json.encode({'course': courseId}),
    );

    if (response.statusCode == 201) {
      _isLoading = false;
      notifyListeners();
      print('Enrollment request sent');
    } else {
      _isLoading = false;
      _hasError = true;
      notifyListeners();
      print('Failed to send enrollment request: ${response.body}');
    }
  }

  Future<void> fetchEnrollmentRequests(String userRole) async {
    if (_token == null) {
      print('Token is null, cannot fetch enrollment requests');
      _hasError = true;
      notifyListeners();
      return;
    }

    _isLoading = true;
    _hasError = false;
    notifyListeners();

    String endpoint =
        userRole == 'student' ? 'student-requests' : 'teacher-requests';

    print(
        'Fetching enrollment requests for role: $userRole with token: $_token');

    final response = await http.get(
      Uri.parse('http://10.0.2.2:8000/api/enrollment-requests/$endpoint/'),
      headers: {
        'Authorization': 'Bearer $_token',
      },
    );

    print('Response status code: ${response.statusCode}');
    print('Response body: ${response.body}');

    if (response.statusCode == 200) {
      _enrollmentRequests = json.decode(response.body);
      _isLoading = false;
      notifyListeners();
    } else {
      _isLoading = false;
      _hasError = true;
      notifyListeners();
      print('Failed to fetch enrollment requests');
    }
  }

  Future<void> approveEnrollment(int requestId) async {
    final response = await http.patch(
      Uri.parse('http://10.0.2.2:8000/api/enrollment-requests/$requestId/'),
      headers: {
        'Authorization': 'Bearer $_token',
        'Content-Type': 'application/json',
      },
      body: json.encode({'status': 'approved'}),
    );

    if (response.statusCode == 200) {
      fetchEnrollmentRequests(
          'teacher'); // Assuming the role is teacher for approval
    } else {
      print('Failed to approve enrollment request');
    }
  }

  Future<void> denyEnrollment(int requestId) async {
    final response = await http.patch(
      Uri.parse('http://10.0.2.2:8000/api/enrollment-requests/$requestId/'),
      headers: {
        'Authorization': 'Bearer $_token',
        'Content-Type': 'application/json',
      },
      body: json.encode({'status': 'denied'}),
    );

    if (response.statusCode == 200) {
      fetchEnrollmentRequests(
          'teacher'); // Assuming the role is teacher for denial
    } else {
      print('Failed to deny enrollment request');
    }
  }

  Future<bool> isUserEnrolled(int courseId, int userId) async {
    _isLoading = true;
    _hasError = false;
    notifyListeners();

    final response = await http.get(
      Uri.parse(
          'http://10.0.2.2:8000/api/enrollments/check/?course=$courseId&user=$userId'),
      headers: {
        'Authorization': 'Bearer $_token',
      },
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      _isLoading = false;
      notifyListeners();
      return data['is_enrolled'];
    } else {
      _isLoading = false;
      _hasError = true;
      notifyListeners();
      print('Failed to check enrollment status');
      return false;
    }
  }
}
