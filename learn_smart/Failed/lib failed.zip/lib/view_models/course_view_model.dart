import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class CourseViewModel extends ChangeNotifier {
  String? _token;
  bool isLoading = false;
  bool hasError = false;
  String? errorMessage;
  List<Map<String, dynamic>> courses = [];
  Map<String, dynamic> courseDetails = {};

  void updateToken(String? token) {
    _token = token;
    notifyListeners();
  }

  Future<void> fetchCourses() async {
    isLoading = true;
    hasError = false;
    errorMessage = null;
    notifyListeners();

    try {
      final response = await http.get(
        Uri.parse('http://10.0.2.2:8000/api/courses/'),
        headers: {
          'Authorization': 'Bearer $_token',
        },
      );

      if (response.statusCode == 200) {
        courses = List<Map<String, dynamic>>.from(json.decode(response.body));
      } else {
        hasError = true;
        errorMessage = 'Failed to fetch courses';
      }
    } catch (error) {
      hasError = true;
      errorMessage = 'An error occurred';
      print("Error: $error");
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> fetchCourseDetail(int courseId) async {
    isLoading = true;
    hasError = false;
    errorMessage = null;
    notifyListeners();

    try {
      final response = await http.get(
        Uri.parse('http://10.0.2.2:8000/api/courses/$courseId/'),
        headers: {
          'Authorization': 'Bearer $_token',
        },
      );

      if (response.statusCode == 200) {
        courseDetails = json.decode(response.body);
      } else {
        hasError = true;
        errorMessage = 'Failed to fetch course details';
      }
    } catch (error) {
      hasError = true;
      errorMessage = 'An error occurred';
      print("Error: $error");
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> createCourse(String name, String description) async {
    isLoading = true;
    hasError = false;
    errorMessage = null;
    notifyListeners();

    try {
      final response = await http.post(
        Uri.parse('http://10.0.2.2:8000/api/courses/'),
        headers: {
          'Authorization': 'Bearer $_token',
          'Content-Type': 'application/json',
        },
        body: json.encode({
          'name': name,
          'description': description,
        }),
      );

      if (response.statusCode == 201) {
        await fetchCourses(); // Refresh the courses list after creating a new course
      } else {
        hasError = true;
        errorMessage = 'Failed to create course';
      }
    } catch (error) {
      hasError = true;
      errorMessage = 'An error occurred';
      print("Error: $error");
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> deleteCourse(int courseId) async {
    isLoading = true;
    hasError = false;
    errorMessage = null;
    notifyListeners();

    try {
      final response = await http.delete(
        Uri.parse('http://10.0.2.2:8000/api/courses/$courseId/'),
        headers: {
          'Authorization': 'Bearer $_token',
        },
      );

      if (response.statusCode == 204) {
        courses.removeWhere((course) => course['id'] == courseId);
        notifyListeners();
      } else {
        hasError = true;
        errorMessage = 'Failed to delete course';
      }
    } catch (error) {
      hasError = true;
      errorMessage = 'An error occurred';
      print("Error: $error");
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> updateCourse(
      int courseId, String name, String description) async {
    isLoading = true;
    hasError = false;
    errorMessage = null;
    notifyListeners();

    try {
      final response = await http.patch(
        Uri.parse('http://10.0.2.2:8000/api/courses/$courseId/'),
        headers: {
          'Authorization': 'Bearer $_token',
          'Content-Type': 'application/json',
        },
        body: json.encode({
          'name': name,
          'description': description,
        }),
      );

      if (response.statusCode == 200) {
        final updatedCourse = json.decode(response.body);
        final index = courses.indexWhere((course) => course['id'] == courseId);
        if (index != -1) {
          courses[index] = updatedCourse;
        }
        notifyListeners();
      } else {
        hasError = true;
        errorMessage = 'Failed to update course';
      }
    } catch (error) {
      hasError = true;
      errorMessage = 'An error occurred';
      print("Error: $error");
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }
}
