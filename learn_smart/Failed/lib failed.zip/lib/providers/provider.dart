import 'package:provider/provider.dart';
import 'package:provider/single_child_widget.dart';

import '../view_models/auth_view_model.dart';
import '../view_models/course_view_model.dart';
import '../view_models/enrollment_view_model.dart';
import '../view_models/module_view_model.dart';
import '../view_models/note_view_model.dart';
import '../view_models/quiz_view_model.dart';
import '../view_models/result_view_model.dart';

class AppProviders {
  static List<SingleChildWidget> providers() {
    return [
      ChangeNotifierProvider(create: (_) => AuthViewModel()),
      ChangeNotifierProxyProvider<AuthViewModel, CourseViewModel>(
        create: (_) => CourseViewModel(),
        update: (context, auth, courses) {
          courses!.updateToken(auth.token);
          return courses;
        },
      ),
      ChangeNotifierProxyProvider<AuthViewModel, ModuleViewModel>(
        create: (_) => ModuleViewModel(),
        update: (context, auth, modules) {
          modules!.updateToken(auth.token);
          return modules;
        },
      ),
      ChangeNotifierProxyProvider<AuthViewModel, NoteViewModel>(
        create: (_) => NoteViewModel(),
        update: (context, auth, notes) {
          notes!.updateToken(auth.token);
          return notes;
        },
      ),
      ChangeNotifierProxyProvider<AuthViewModel, QuizViewModel>(
        create: (_) => QuizViewModel(),
        update: (context, auth, quizzes) {
          quizzes!.updateToken(auth.token);
          return quizzes;
        },
      ),
      ChangeNotifierProxyProvider<AuthViewModel, ResultViewModel>(
        create: (_) => ResultViewModel(),
        update: (context, auth, results) {
          results!.updateToken(auth.token);
          return results;
        },
      ),
      ChangeNotifierProxyProvider<AuthViewModel, EnrollmentViewModel>(
        create: (_) => EnrollmentViewModel(),
        update: (context, auth, enrollments) {
          enrollments!.updateToken(auth.token);
          return enrollments;
        },
      ),
    ];
  }
}
