import 'dart:async';
import 'package:flutter/material.dart';
import 'package:learn_smart/screens/widgets/app_bar.dart';
import 'package:learn_smart/services/api_service.dart';
import 'package:learn_smart/models/quiz.dart';
import 'package:provider/provider.dart';
import 'package:learn_smart/view_models/auth_view_model.dart';

class QuizDetailScreen extends StatefulWidget {
  final int moduleId;
  final int quizId;
  final bool isStudentEnrolled;
  final bool isEditMode;
  final Map<String, dynamic>? generatedQuiz;

  QuizDetailScreen({
    required this.moduleId,
    required this.quizId,
    required this.isStudentEnrolled,
    this.isEditMode = false,
    this.generatedQuiz,
  });

  @override
  _QuizDetailScreenState createState() => _QuizDetailScreenState();
}

class _QuizDetailScreenState extends State<QuizDetailScreen> {
  late Quiz quiz;
  bool _isLoading = true;
  bool _hasError = false;
  String _errorMessage = '';
  late ApiService _apiService;
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _contentController = TextEditingController();
  List<Map<String, dynamic>> parsedQuestions = [];

  int currentQuestionIndex = 0;
  String selectedAnswer = '';
  Map<int, String> selectedAnswers = {};
  bool showResult = false;
  bool showReview = false;

  double progress = 0.0;
  int correctAnswersCount = 0;
  Timer? _timer;
  int timeLeft = 30; // 30 seconds per question
  bool isStudent = false;
  bool hasQuizStarted = false;
  bool isGeneratedQuiz = false;
  bool isSaved = false;

  Future<void> _processGeneratedQuiz() async {
    if (widget.generatedQuiz != null) {
      setState(() {
        isGeneratedQuiz = true;
        _parseQuizContent(widget.generatedQuiz!['content']);
      });
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final authViewModel = Provider.of<AuthViewModel>(context, listen: false);
      _apiService = ApiService(baseUrl: 'http://10.0.2.2:8000/api/');
      _apiService.updateToken(authViewModel.user.token ?? '');
      await _loadQuizDetails();
    });
  }

  Future<void> _loadQuizDetails() async {
    try {
      if (widget.generatedQuiz != null) {
        final content = widget.generatedQuiz!['quiz_content'] ?? widget.generatedQuiz!['content'];
        
        quiz = Quiz(
          id: -1,
          title: widget.generatedQuiz!['title'] ?? 'Generated Quiz',
          content: content?.toString() ?? '',
          isAIGenerated: true,
          isSaved: false,
        );

        if (content != null) {
          _parseQuizContent(content.toString());
          if (!widget.isEditMode && isStudent) _startTimer();
        }
      } else {
        final response = await _apiService.getQuizDetail(widget.moduleId, widget.quizId);
        quiz = response;
        
        if (quiz.content != null) {
          _parseQuizContent(quiz.content);
          if (!widget.isEditMode && isStudent) _startTimer();
        }
      }

      setState(() {
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _hasError = true;
        _errorMessage = e.toString();
        _isLoading = false;
      });
      print('Error loading quiz: $e');
    }
  }

  void _startTimer() {
    timeLeft = 30;
    _timer?.cancel();
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        if (timeLeft > 0) {
          timeLeft--;
          progress = 1 - (timeLeft / 30);
        } else {
          timer.cancel();
          _goToNextQuestion();
        }
      });
    });
  }

  void _parseQuizContent(String? content) {
    if (content == null || content.isEmpty) {
      print('Content is null or empty');
      return;
    }

    try {
      parsedQuestions.clear();
      
      // Split by question numbers (1., 2., etc.)
      List<String> blocks = content.split(RegExp(r'\d+\.\s+'));
      
      // Skip the first empty block if exists
      for (String block in blocks.skip(1)) {
        if (block.trim().isEmpty) continue;

        // Split block into lines and clean up
        List<String> lines = block
            .split('\n')
            .map((line) => line.trim())
            .where((line) => line.isNotEmpty)
            .toList();

        if (lines.length >= 5) { // Question + 4 options + correct answer
          String questionText = lines[0].trim();
          List<String> options = [];
          String correctAnswer = '';

          // Process each line
          for (String line in lines.skip(1)) { // Skip question text
            if (line.startsWith(RegExp(r'[A-D]\)'))) {
              // Extract option text (remove A), B), etc.)
              String optionText = line.substring(2).trim();
              options.add(optionText);
            } else if (line.startsWith('Correct Answer:')) {
              correctAnswer = line.split(':')[1].trim();
            }
          }

          // Add question if we have all components
          if (options.length == 4 && correctAnswer.isNotEmpty) {
            parsedQuestions.add({
              'question': questionText,
              'options': options,
              'correctAnswer': correctAnswer,
            });

            print('Added Question: $questionText');
            print('Options: $options');
            print('Correct Answer: $correctAnswer');
          }
        }
      }

      print('Total parsed questions: ${parsedQuestions.length}');

      // Update UI
      setState(() {
        isGeneratedQuiz = widget.generatedQuiz != null;
      });

    } catch (e) {
      print('Error parsing quiz content: $e');
      // Show error in UI
      setState(() {
        _hasError = true;
        _errorMessage = 'Failed to parse quiz content: $e';
      });
    }
  }

  // Helper method to convert option letter to index
  int _getOptionIndex(String letter) {
    return letter.codeUnitAt(0) - 'A'.codeUnitAt(0);
  }

  // Helper method to get option letter from index
  String _getOptionLetter(int index) {
    return String.fromCharCode('A'.codeUnitAt(0) + index);
  }

  void _goToNextQuestion() {
    if (currentQuestionIndex < parsedQuestions.length - 1) {
      setState(() {
        currentQuestionIndex++;
        selectedAnswer = selectedAnswers[currentQuestionIndex] ?? '';
        timeLeft = 30; // Reset timer for new question
      });
    } else {
      _submitQuiz();
    }
  }

  void _calculateResult() {
    correctAnswersCount = 0;
    for (int i = 0; i < parsedQuestions.length; i++) {
      String correctAnswer = parsedQuestions[i]['correctAnswer'];
      String? selectedAnswer = selectedAnswers[i];

      if (selectedAnswer != null &&
          correctAnswer == selectedAnswer.substring(0, 1)) {
        correctAnswersCount++;
      }
    }
  }

  void _submitQuiz() {
    _calculateResult();
    setState(() {
      showResult = true;
      _timer?.cancel();
    });
  }

  Widget _buildQuizContent() {
    if (parsedQuestions.isEmpty) {
      return Center(child: Text('No questions available'));
    }

    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Question ${currentQuestionIndex + 1}',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.grey[600],
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  SizedBox(height: 12),
                  
                  Text(
                    parsedQuestions[currentQuestionIndex]['question'],
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 24),

                  // Options
                  ...List.generate(
                    (parsedQuestions[currentQuestionIndex]['options'] as List).length,
                    (index) {
                      final option = parsedQuestions[currentQuestionIndex]['options'][index];
                      final isSelected = selectedAnswer == option;
                      final correctAnswerLetter = parsedQuestions[currentQuestionIndex]['correctAnswer'];
                      final isCorrectAnswer = _getOptionLetter(index) == correctAnswerLetter;

                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12.0),
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: isCorrectAnswer 
                                  ? Colors.green 
                                  : isSelected 
                                      ? Colors.blue 
                                      : Colors.grey[300]!,
                              width: isCorrectAnswer || isSelected ? 2 : 1,
                            ),
                            borderRadius: BorderRadius.circular(8),
                            color: isCorrectAnswer 
                                ? Colors.green.withOpacity(0.1)
                                : isSelected 
                                    ? Colors.blue.withOpacity(0.1)
                                    : Colors.white,
                          ),
                          child: RadioListTile<String>(
                            value: option,
                            groupValue: selectedAnswer,
                            onChanged: (value) {
                              setState(() {
                                selectedAnswer = value!;
                                selectedAnswers[currentQuestionIndex] = value;
                              });
                            },
                            title: Row(
                              children: [
                                Text(
                                  '${_getOptionLetter(index)}) ',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey[600],
                                  ),
                                ),
                                Expanded(
                                  child: Text(
                                    option,
                                    style: TextStyle(
                                      color: isCorrectAnswer 
                                          ? Colors.green
                                          : isSelected 
                                              ? Colors.blue 
                                              : Colors.black87,
                                      fontWeight: isCorrectAnswer 
                                          ? FontWeight.bold 
                                          : FontWeight.normal,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            secondary: isCorrectAnswer
                                ? Icon(Icons.check_circle, color: Colors.green)
                                : null,
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
        
        // Bottom action buttons
        if (widget.generatedQuiz != null && !isSaved)
          _buildGeneratedQuizActions(),
      ],
    );
  }

  Widget _buildReviewContent() {
    return ListView.builder(
      padding: EdgeInsets.all(16),
      itemCount: parsedQuestions.length,
      itemBuilder: (context, index) {
        final question = parsedQuestions[index];
        final selectedAnswer = selectedAnswers[index] ?? '';
        final correctAnswer = question['correctAnswer'];

        return Card(
          margin: EdgeInsets.only(bottom: 16),
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Question ${index + 1}',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[600],
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  question['question'],
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 16),
                ...question['options'].map<Widget>((option) {
                  bool isSelected = selectedAnswer == option;
                  bool isCorrect = option.startsWith(correctAnswer);

                  Color getBackgroundColor() {
                    if (isSelected && isCorrect) return Color(0xFFE8F5E9);
                    if (isSelected && !isCorrect) return Color(0xFFFFEBEE);
                    if (isCorrect) return Color(0xFFE8F5E9);
                    return Colors.white;
                  }

                  Color getBorderColor() {
                    if (isSelected && isCorrect) return Color(0xFF4CAF50);
                    if (isSelected && !isCorrect) return Color(0xFFEF5350);
                    if (isCorrect) return Color(0xFF4CAF50);
                    return Colors.grey[300]!;
                  }

                  return Container(
                    margin: EdgeInsets.only(bottom: 8),
                    decoration: BoxDecoration(
                      color: getBackgroundColor(),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: getBorderColor(),
                        width: 2,
                      ),
                    ),
                    padding: EdgeInsets.symmetric(vertical: 16, horizontal: 20),
                    child: Row(
                      children: [
                        if (isSelected && isCorrect)
                          Icon(Icons.check_circle, color: Color(0xFF4CAF50))
                        else if (isSelected && !isCorrect)
                          Icon(Icons.cancel, color: Color(0xFFEF5350))
                        else if (isCorrect)
                          Icon(Icons.check_circle_outline,
                              color: Color(0xFF4CAF50))
                        else
                          Icon(Icons.radio_button_unchecked,
                              color: Colors.grey),
                        SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            option,
                            style: TextStyle(fontSize: 16),
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildResultView() {
    int totalQuestions = parsedQuestions.length;
    double percentage = (correctAnswersCount / totalQuestions) * 100;

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          'Quiz Completed!',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Color(0xFF1A4A44),
          ),
        ),
        SizedBox(height: 20),
        Container(
          padding: EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Color(0xFFE3F2FD),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            children: [
              Text(
                '${percentage.round()}%',
                style: TextStyle(
                  fontSize: 48,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1A4A44),
                ),
              ),
              Text(
                '$correctAnswersCount out of $totalQuestions correct',
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 32),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                setState(() {
                  showReview = true;
                });
              },
              child: Text('Review Answers'),
              style: ElevatedButton.styleFrom(
                foregroundColor: Color(0xFF1A4A44),
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            SizedBox(width: 16),
            OutlinedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Return'),
              style: OutlinedButton.styleFrom(
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildGeneratedQuizActions() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            offset: Offset(0, -2),
            blurRadius: 4,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          // Save Button
          IconButton(
            onPressed: _saveQuiz,
            icon: Icon(
              Icons.check_circle,
              color: Colors.green,
              size: 32,
            ),
            tooltip: 'Save Quiz',
          ),
          
          // Regenerate Button
          ElevatedButton.icon(
            onPressed: _regenerateQuiz,
            icon: Icon(Icons.refresh),
            label: Text('Regenerate'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue,
              foregroundColor: Colors.white,
              padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
          
          // Cancel Button
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: Icon(
              Icons.cancel,
              color: Colors.red,
              size: 32,
            ),
            tooltip: 'Cancel',
          ),
        ],
      ),
    );
  }

  Future<void> _saveQuiz() async {
    try {
      setState(() => _isLoading = true);
      
      Map<String, dynamic> quizData = {
        'title': quiz.title ?? '',
        'content': quiz.content ?? '',
      };
      
      await _apiService.saveAIQuiz(
        widget.moduleId,
        quizData,
      );

      setState(() => isSaved = true);
      _showSuccessSnackBar('Quiz saved successfully');
      Navigator.pop(context, true);
    } catch (e) {
      _showErrorSnackBar('Failed to save quiz: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _regenerateQuiz() async {
    try {
      setState(() => _isLoading = true);
      
      final response = await _apiService.generateQuizFromMultipleNotes(
        widget.moduleId,
        widget.generatedQuiz?['note_ids'] ?? [],
      );

      setState(() {
        quiz = Quiz(
          id: widget.quizId,
          title: response['title'],
          content: response['quiz_content'],
          isAIGenerated: true,
          isSaved: false,
        );
        _parseQuizContent(quiz.content);
      });
    } catch (e) {
      _showErrorSnackBar('Failed to regenerate quiz: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
      ),
    );
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'Quiz'),
      body: Column(
        children: [
          // Main quiz content
          Expanded(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ...List.generate(
                      parsedQuestions.length,
                      (index) {
                        final question = parsedQuestions[index];
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Question ${index + 1}',
                              style: TextStyle(
                                fontSize: 18,
                                color: Colors.grey[600],
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              question['question'],
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 16),
                            ...List.generate(
                              (question['options'] as List).length,
                              (optionIndex) {
                                final option = question['options'][optionIndex];
                                final isCorrectAnswer = 
                                    question['correctAnswer'] == 
                                    String.fromCharCode(65 + optionIndex);

                                return Container(
                                  margin: EdgeInsets.only(bottom: 8),
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: isCorrectAnswer 
                                          ? Colors.green 
                                          : Colors.grey[300]!,
                                      width: isCorrectAnswer ? 2 : 1,
                                    ),
                                    borderRadius: BorderRadius.circular(8),
                                    color: isCorrectAnswer 
                                        ? Colors.green.withOpacity(0.1)
                                        : Colors.white,
                                  ),
                                  child: ListTile(
                                    leading: Text(
                                      '${String.fromCharCode(65 + optionIndex)})',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: isCorrectAnswer 
                                            ? Colors.green 
                                            : Colors.grey[600],
                                      ),
                                    ),
                                    title: Text(
                                      option,
                                      style: TextStyle(
                                        color: isCorrectAnswer 
                                            ? Colors.green 
                                            : Colors.black87,
                                        fontWeight: isCorrectAnswer 
                                            ? FontWeight.bold 
                                            : FontWeight.normal,
                                      ),
                                    ),
                                    trailing: isCorrectAnswer
                                        ? Icon(Icons.check_circle, 
                                            color: Colors.green)
                                        : null,
                                  ),
                                );
                              },
                            ),
                            SizedBox(height: 24),
                          ],
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
          
          // Bottom action buttons
          if (widget.generatedQuiz != null && !isSaved)
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    offset: Offset(0, -2),
                    blurRadius: 4,
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  IconButton(
                    onPressed: _saveQuiz,
                    icon: Icon(
                      Icons.check_circle,
                      color: Colors.green,
                      size: 32,
                    ),
                    tooltip: 'Save Quiz',
                  ),
                  ElevatedButton.icon(
                    onPressed: _regenerateQuiz,
                    icon: Icon(Icons.refresh),
                    label: Text('Regenerate'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      foregroundColor: Colors.white,
                      padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: Icon(
                      Icons.cancel,
                      color: Colors.red,
                      size: 32,
                    ),
                    tooltip: 'Cancel',
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
