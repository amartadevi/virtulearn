import 'dart:async';
import 'package:flutter/material.dart';
import 'package:learn_smart/services/api_service.dart';
import 'package:learn_smart/models/quiz.dart';
import 'package:provider/provider.dart';
import 'package:learn_smart/view_models/auth_view_model.dart';

class QuizDetailScreen extends StatefulWidget {
  final int moduleId;
  final int quizId;
  final bool isStudentEnrolled;
  final bool isEditMode;

  QuizDetailScreen({
    required this.moduleId,
    required this.quizId,
    required this.isStudentEnrolled,
    this.isEditMode = false,
  });

  @override
  _QuizDetailScreenState createState() => _QuizDetailScreenState();
}

class _QuizDetailScreenState extends State<QuizDetailScreen> {
  late Future<Quiz> quizFuture;
  late ApiService _apiService;
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _contentController = TextEditingController();
  bool _isLoading = true;
  List<Map<String, dynamic>> parsedQuestions = [];

  int currentQuestionIndex = 0;
  String selectedAnswer = '';
  Map<int, String> selectedAnswers = {};
  bool showResult = false;

  double progress = 0.0; // Progress value for timer
  int correctAnswersCount = 0; // To track the number of correct answers
  Timer? _timer; // Timer for each question

  @override
  void initState() {
    super.initState();
    final authViewModel = Provider.of<AuthViewModel>(context, listen: false);
    _apiService = ApiService(baseUrl: 'http://10.0.2.2:8000/api/');
    _apiService.updateToken(authViewModel.user.token ?? '');
    quizFuture = _apiService.getQuizDetail(widget.moduleId, widget.quizId);
  }

  Future<void> _loadQuizDetails() async {
    final quiz =
        await _apiService.getQuizDetail(widget.moduleId, widget.quizId);
    _titleController.text = quiz.title;
    _contentController.text = quiz.content;
    setState(() {
      _isLoading = false;
    });
  }

  void _parseQuizContent(String content) {
    List<String> questionBlocks = content.split("\n\n");
    for (var block in questionBlocks) {
      List<String> lines = block.split("\n");
      if (lines.length >= 6) {
        String questionText = lines[0];
        String optionA = lines[1];
        String optionB = lines[2];
        String optionC = lines[3];
        String optionD = lines[4];
        String correctAnswer = _extractCorrectAnswer(block);
        parsedQuestions.add({
          'question': questionText,
          'options': [optionA, optionB, optionC, optionD],
          'correctAnswer': correctAnswer,
        });
      }
    }
  }

  String _extractCorrectAnswer(String questionBlock) {
    final correctAnswerPattern = RegExp(r'Correct Answer:\s?([A-D])');
    final match = correctAnswerPattern.firstMatch(questionBlock);
    return match?.group(1) ?? '';
  }

  // Start a timer for the current question
  void _startTimer() {
    progress = 0.0; // Reset progress for the new question
    _timer?.cancel(); // Cancel any existing timer

    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        progress += 0.1; // Increment progress bar
        if (progress >= 1.0) {
          timer.cancel(); // Cancel timer when it reaches 100%
          _goToNextQuestion(); // Automatically go to the next question
        }
      });
    });
  }

  void _goToNextQuestion() {
    setState(() {
      // Automatically navigate to the next question
      currentQuestionIndex++;
      selectedAnswer = selectedAnswers[currentQuestionIndex] ?? '';
      if (currentQuestionIndex < parsedQuestions.length) {
        _startTimer(); // Start timer for the new question
      } else {
        _submitQuiz(); // If no more questions, submit the quiz
      }
    });
  }

  // Submit quiz method
  void _submitQuiz() {
    _calculateResult();
    setState(() {
      showResult = true;
      _timer?.cancel(); // Cancel timer when submitting
    });
  }

  // Calculate the result by comparing selected answers with correct answers
  void _calculateResult() {
    correctAnswersCount = 0;
    for (int i = 0; i < parsedQuestions.length; i++) {
      String correctAnswer = parsedQuestions[i]['correctAnswer'];
      String? selectedAnswer = selectedAnswers[i];

      // Compare the correct answer with the user's selected answer
      if (selectedAnswer != null &&
          correctAnswer == selectedAnswer.substring(0, 1)) {
        correctAnswersCount++;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final authViewModel = Provider.of<AuthViewModel>(context);
    final isTeacher = authViewModel.user.role == 'teacher'; // Role check

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isEditMode ? 'Edit Quiz' : 'Quiz Details'),
      ),
      body: FutureBuilder<Quiz>(
        future: quizFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (snapshot.hasData) {
            final quiz = snapshot.data!;
            if (parsedQuestions.isEmpty) {
              _parseQuizContent(quiz.content);

              if (!isTeacher)
                _startTimer(); // Start timer after loading questions
            }
            if (showResult) {
              return _buildResultView();
            } else {
              return isTeacher
                  ? _buildQuizViewForTeacher(quiz)
                  : _buildQuizViewForStudent(quiz);
            }
          } else {
            return Center(child: Text('No data available'));
          }
        },
      ),
    );
  }

  // Build the quiz view
  Widget _buildQuizView(Quiz quiz) {
    return Column(
      mainAxisAlignment:
          MainAxisAlignment.center, // Center the content vertically
      children: [
        LinearProgressIndicator(
          value: progress,
          backgroundColor: Colors.grey[300],
          valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
        ),
        SizedBox(height: 20),
        Expanded(
          child: Center(
            // Center the quiz content
            child: _buildQuizContent(),
          ),
        ),
      ],
    );
  }

  Widget _buildQuizViewForTeacher(Quiz quiz) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              quiz.title,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              quiz.content,
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            Text(
              'Questions:',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            ...parsedQuestions.map((question) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 16.0),
                child: Text(
                  'Q: ${question['question']}',
                  style: TextStyle(fontSize: 18),
                ),
              );
            }).toList(),
          ],
        ),
      ),
    );
  }

  Widget _buildQuizViewForStudent(Quiz quiz) {
    return Column(
      mainAxisAlignment:
          MainAxisAlignment.center, // Center the content vertically
      children: [
        LinearProgressIndicator(
          value: progress,
          backgroundColor: Colors.grey[300],
          valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
        ),
        SizedBox(height: 20),
        Expanded(
          child: Center(
            // Center the quiz content
            child: _buildQuizContent(),
          ),
        ),
      ],
    );
  }

  // Build the quiz content view
  Widget _buildQuizContent() {
    if (parsedQuestions.isEmpty) {
      return Center(child: Text('No quiz content available.'));
    }

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.center, // Center the content horizontally
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Q: ${parsedQuestions[currentQuestionIndex]['question']}',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center, // Center the question text
            ),
          ),
          SizedBox(height: 10),
          ...parsedQuestions[currentQuestionIndex]['options']
              .map<Widget>((option) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: RadioListTile<String>(
                title: Text(option),
                value: option,
                groupValue: selectedAnswer,
                onChanged: (value) {
                  setState(() {
                    selectedAnswer = value!;
                    selectedAnswers[currentQuestionIndex] = value;
                  });
                },
              ),
            );
          }).toList(),
          SizedBox(height: 20),
          Center(
            // Center the buttons
            child: currentQuestionIndex < parsedQuestions.length - 1
                ? ElevatedButton(
                    onPressed: () {
                      _goToNextQuestion(); // Go to the next question
                    },
                    child: Text('Next'),
                  )
                : ElevatedButton(
                    onPressed: _submitQuiz,
                    child: Text('Submit'),
                  ),
          ),
        ],
      ),
    );
  }

  // Build the result view
  Widget _buildResultView() {
    int totalQuestions = parsedQuestions.length;
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Quiz Completed!',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 20),
          Text(
            'You got $correctAnswersCount out of $totalQuestions correct.',
            style: TextStyle(fontSize: 20),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context); // Go back to the previous screen
            },
            child: Text('Return'),
          ),
        ],
      ),
    );
  }

  // Build the edit quiz form (unchanged)
  Widget _buildEditQuizForm(Quiz quiz) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: _titleController,
            decoration: InputDecoration(labelText: 'Quiz Title'),
          ),
          SizedBox(height: 10),
          TextField(
            controller: _contentController,
            decoration: InputDecoration(labelText: 'Quiz Content'),
            maxLines: null,
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () async {
              // Implement the edit quiz logic here
            },
            child: Text('Save Changes'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _timer?.cancel(); // Cancel the timer when disposing the widget
    super.dispose();
  }
}
