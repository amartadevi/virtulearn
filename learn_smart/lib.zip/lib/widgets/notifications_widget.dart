import 'package:flutter/material.dart';
import 'package:learn_smart/view_models/enrollment_view_model.dart';
import 'package:provider/provider.dart';

class NotificationsWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Provider.of<EnrollmentViewModel>(context);

    return Card(
      child: ListTile(
        title: Text('Enrollment Requests'),
        trailing: Icon(Icons.notifications),
        onTap: () {
          Navigator.pushNamed(context, '/enrollment-requests');
        },
      ),
    );
  }
}
