import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class NoteViewModel extends ChangeNotifier {
  bool isLoading = false;
  bool hasError = false;
  String? errorMessage;
  List<Map<String, dynamic>> notes = [];
  String? token;

  void updateToken(String? newToken) {
    token = newToken;
    notifyListeners();
  }

  Future<void> fetchNotes(int moduleId) async {
    _setLoadingState(true);
    final url = 'http://10.0.2.2:8000/api/modules/$moduleId/notes/';

    try {
      final response = await http.get(
        Uri.parse(url),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        notes = List<Map<String, dynamic>>.from(json.decode(response.body));
        _setErrorState(false, null);
      } else {
        _setErrorState(
            true, 'Failed to fetch notes. Status code: ${response.statusCode}');
      }
    } catch (error) {
      _setErrorState(true, 'Error occurred: $error');
    } finally {
      _setLoadingState(false);
    }
  }

  Future<bool> createNote(int moduleId, String title, String content) async {
    _setLoadingState(true);
    final url = 'http://10.0.2.2:8000/api/modules/$moduleId/notes/';
    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: json.encode({
          'title': title,
          'content': content,
        }),
      );

      if (response.statusCode == 201) {
        await fetchNotes(moduleId); // Refresh the list of notes
        return true;
      } else {
        _setErrorState(
            true, 'Failed to create note. Status code: ${response.statusCode}');
        return false;
      }
    } catch (error) {
      _setErrorState(true, 'Error occurred: $error');
      return false;
    } finally {
      _setLoadingState(false);
    }
  }

  Future<bool> updateNote(
      int noteId, int moduleId, String title, String content) async {
    _setLoadingState(true);
    final url = 'http://10.0.2.2:8000/api/modules/$moduleId/notes/$noteId/';
    try {
      final response = await http.put(
        Uri.parse(url),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: json.encode({
          'title': title,
          'content': content,
        }),
      );

      if (response.statusCode == 200) {
        await fetchNotes(moduleId); // Refresh the list of notes
        return true;
      } else {
        _setErrorState(
            true, 'Failed to update note. Status code: ${response.statusCode}');
        return false;
      }
    } catch (error) {
      _setErrorState(true, 'Error occurred: $error');
      return false;
    } finally {
      _setLoadingState(false);
    }
  }

  Future<bool> deleteNote(int noteId, int moduleId) async {
    _setLoadingState(true);
    final url = 'http://10.0.2.2:8000/api/modules/$moduleId/notes/$noteId/';
    try {
      final response = await http.delete(
        Uri.parse(url),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 204) {
        await fetchNotes(moduleId); // Refresh the list of notes
        return true;
      } else {
        _setErrorState(
            true, 'Failed to delete note. Status code: ${response.statusCode}');
        return false;
      }
    } catch (error) {
      _setErrorState(true, 'Error occurred: $error');
      return false;
    } finally {
      _setLoadingState(false);
    }
  }

  void _setLoadingState(bool state) {
    isLoading = state;
    notifyListeners();
  }

  void _setErrorState(bool state, String? message) {
    hasError = state;
    errorMessage = message;
    notifyListeners();
  }
}
