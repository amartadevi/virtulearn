import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class EnrollmentModel extends ChangeNotifier {
  bool isLoading = false;
  bool hasError = false;
  List<Map<String, dynamic>> enrollmentRequests = [];
  String? _token;

  void updateToken(String? token) {
    _token = token;
    notifyListeners();
  }

  Future<void> fetchEnrollmentRequests(String role, String token) async {
    isLoading = true;
    hasError = false;
    notifyListeners();

    final url = role == 'teacher'
        ? 'http://10.0.2.2:8000/api/enrollment-requests/teacher-requests/'
        : 'http://10.0.2.2:8000/api/enrollment-requests/student-requests/';

    try {
      final response = await http.get(
        Uri.parse(url),
        headers: {
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        enrollmentRequests =
            List<Map<String, dynamic>>.from(json.decode(response.body));
      } else {
        hasError = true;
      }
    } catch (error) {
      hasError = true;
      print("Error: $error");
    }

    isLoading = false;
    notifyListeners();
  }

  Future<void> sendEnrollmentRequest(int courseId, String token) async {
    final url = 'http://10.0.2.2:8000/api/enrollment-requests/create/';
    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: json.encode({'course': courseId}),
      );

      if (response.statusCode == 201) {
        print('Enrollment request sent');
        fetchEnrollmentRequests('student', token); // Refresh list
      } else {
        print(
            'Failed to send enrollment request. Status code: ${response.statusCode}');
        hasError = true;
      }
    } catch (e) {
      print('Error sending enrollment request: $e');
      hasError = true;
    }

    notifyListeners();
  }

  Future<void> approveEnrollment(int id, String token) async {
    final url = 'http://10.0.2.2:8000/api/enrollment-requests/$id/';
    try {
      final response = await http.patch(
        Uri.parse(url),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: json.encode({'status': 'approved'}),
      );

      if (response.statusCode == 200) {
        print('Enrollment request approved');
        fetchEnrollmentRequests('teacher', token); // Refresh list
      } else {
        print(
            'Failed to approve enrollment request. Status code: ${response.statusCode}');
        hasError = true;
      }
    } catch (e) {
      print('Error approving enrollment request: $e');
      hasError = true;
    }

    notifyListeners();
  }

  Future<void> denyEnrollment(int id, String token) async {
    final url = 'http://10.0.2.2:8000/api/enrollment-requests/$id/';
    try {
      final response = await http.patch(
        Uri.parse(url),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: json.encode({'status': 'denied'}),
      );

      if (response.statusCode == 200) {
        print('Enrollment request denied');
        fetchEnrollmentRequests('teacher', token); // Refresh list
      } else {
        print(
            'Failed to deny enrollment request. Status code: ${response.statusCode}');
        hasError = true;
      }
    } catch (e) {
      print('Error denying enrollment request: $e');
      hasError = true;
    }

    notifyListeners();
  }
}
