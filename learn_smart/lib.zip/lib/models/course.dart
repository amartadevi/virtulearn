class Course {
  final int id;
  final String name;
  final String code;
  final String description;
  final String createdByUsername;
  final String createdByRole;
  final List<String> students;
  final String? imageUrl;

  Course({
    required this.id,
    required this.name,
    required this.code,
    required this.description,
    required this.createdByUsername,
    required this.createdByRole,
    required this.students,
    required this.imageUrl,
  });

  factory Course.fromJson(Map<String, dynamic> json) {
    return Course(
      id: json['id'],
      name: json['name'],
      code: json['code'],
      description: json['description'],
      createdByUsername: json['created_by']['username'],
      createdByRole: json['created_by']['role'],
      students: List<String>.from(json['students']),
      imageUrl: json['image'],
    );
  }

  // Method to convert a Course object to a JSON object
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'code': code,
      'description': description,
      'created_by': {
        'username': createdByUsername,
        'role': createdByRole,
      },
      'students': students,
      'image': imageUrl,
    };
  }
}
