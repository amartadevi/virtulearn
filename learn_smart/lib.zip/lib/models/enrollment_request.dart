import 'package:flutter/material.dart';
import 'package:learn_smart/models/enrollment_model.dart';
import 'package:learn_smart/models/user.dart';
import 'package:provider/provider.dart';

class EnrollmentRequestsScreen extends StatefulWidget {
  @override
  _EnrollmentRequestsScreenState createState() =>
      _EnrollmentRequestsScreenState();
}

class _EnrollmentRequestsScreenState extends State<EnrollmentRequestsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final user = Provider.of<User>(context, listen: false);
      final enrollmentModel =
          Provider.of<EnrollmentModel>(context, listen: false);

      if (user.role != null && user.token != null) {
        enrollmentModel.fetchEnrollmentRequests(user.role!, user.token!);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final enrollmentModel = Provider.of<EnrollmentModel>(context);
    final user = Provider.of<User>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Enrollment Requests'),
      ),
      body: enrollmentModel.isLoading
          ? Center(child: CircularProgressIndicator())
          : enrollmentModel.hasError
              ? Center(child: Text('Error fetching enrollment requests'))
              : ListView.builder(
                  itemCount: enrollmentModel.enrollmentRequests.length,
                  itemBuilder: (context, index) {
                    final request = enrollmentModel.enrollmentRequests[index];
                    return ListTile(
                      title: Text(
                          '${request['course_name']} - ${request['student_username']}'),
                      subtitle: Text('Status: ${request['status']}'),
                      trailing: !user.isStudent()
                          ? Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: Icon(Icons.check),
                                  onPressed: () async {
                                    if (user.token != null) {
                                      await enrollmentModel.approveEnrollment(
                                          request['id'], user.token!);
                                      final snackBar = SnackBar(
                                        content: Text(enrollmentModel.hasError
                                            ? 'Failed to approve enrollment request'
                                            : 'Enrollment request approved'),
                                      );
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(snackBar);
                                    }
                                  },
                                ),
                                IconButton(
                                  icon: Icon(Icons.close),
                                  onPressed: () async {
                                    if (user.token != null) {
                                      await enrollmentModel.denyEnrollment(
                                          request['id'], user.token!);
                                      final snackBar = SnackBar(
                                        content: Text(enrollmentModel.hasError
                                            ? 'Failed to deny enrollment request'
                                            : 'Enrollment request denied'),
                                      );
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(snackBar);
                                    }
                                  },
                                ),
                              ],
                            )
                          : null,
                    );
                  },
                ),
    );
  }
}
