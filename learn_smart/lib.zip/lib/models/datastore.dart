import 'course.dart';

class DataStore {
  static Map<int, Course> courses = {};

  static void addCourse(Course course) {
    courses[course.id] = course;
  }

  static Course? getCourse(int id) {
    return courses[id];
  }

  static void removeCourse(int id) {
    courses.remove(id);
  }

  static List<Course> getAllCourses() {
    return courses.values.toList();
  }

  // Modules

  static final Map<int, List<dynamic>> _modules =
      {}; // Store modules by courseId

  // Set Modules for a Course
  static void setModules(int courseId, List<dynamic> modules) {
    _modules[courseId] = modules;
  }

  // Get Modules for a Course
  static List<dynamic> getModules(int courseId) {
    return _modules[courseId] ?? [];
  }

  // Add a Module to a Course
  static void addModule(int courseId, dynamic module) {
    _modules[courseId]?.add(module);
  }

  // Update a Module in a Course
  static void updateModule(int courseId, int moduleId, dynamic updatedModule) {
    final modules = _modules[courseId];
    if (modules != null) {
      final index = modules.indexWhere((m) => m['id'] == moduleId);
      if (index != -1) {
        modules[index] = updatedModule;
      }
    }
  }

  // Remove a Module from a Course
  static void removeModule(int courseId, int moduleId) {
    final modules = _modules[courseId];
    if (modules != null) {
      modules.removeWhere((m) => m['id'] == moduleId);
    }
  }
}
