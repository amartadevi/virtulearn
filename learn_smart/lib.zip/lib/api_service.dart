import 'package:http/http.dart' as http;
import 'dart:convert';

import 'models/course.dart';
import 'models/datastore.dart';

class ApiService {
  final String baseUrl;
  String? _token;

  ApiService({required this.baseUrl});

  void updateToken(String token) {
    _token = token;
  }

  Future<void> fetchCourses() async {
    try {
      final response = await http.get(
        Uri.parse(baseUrl + 'courses/'),
        headers: {
          'Authorization': 'Bearer $_token',
        },
      );

      if (response.statusCode == 200) {
        List<dynamic> coursesJson = json.decode(response.body);
        for (var courseJson in coursesJson) {
          Course course = Course.fromJson(courseJson);
          DataStore.addCourse(course); // Update DataStore with fetched courses
        }
      } else {
        throw Exception('Failed to load courses');
      }
    } catch (e) {
      print('Error fetching courses: $e');
      throw e;
    }
  }

  Future<void> editCourse(int courseId, String name, String description) async {
    try {
      final response = await http.put(
        Uri.parse(baseUrl + 'courses/$courseId/'),
        headers: {
          'Authorization': 'Bearer $_token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'name': name,
          'description': description,
        }),
      );

      if (response.statusCode == 200) {
        Course updatedCourse = Course.fromJson(json.decode(response.body));
        DataStore.addCourse(
            updatedCourse); // Update DataStore with edited course
      } else {
        throw Exception('Failed to edit course');
      }
    } catch (e) {
      print('Error editing course: $e');
      throw e;
    }
  }

  Future<void> deleteCourse(int courseId) async {
    try {
      final response = await http.delete(
        Uri.parse(baseUrl + 'courses/$courseId/'),
        headers: {
          'Authorization': 'Bearer $_token',
        },
      );

      if (response.statusCode == 204) {
        DataStore.removeCourse(courseId); // Remove course from DataStore
      } else {
        throw Exception('Failed to delete course');
      }
    } catch (e) {
      print('Error deleting course: $e');
      throw e;
    }
  }

  Future<Course?> getCourseDetail(int courseId) async {
    try {
      final response = await http.get(
        Uri.parse(baseUrl + 'courses/$courseId/'),
        headers: {
          'Authorization': 'Bearer $_token',
        },
      );

      if (response.statusCode == 200) {
        Course course = Course.fromJson(json.decode(response.body));
        DataStore.addCourse(course); // Ensure DataStore is up-to-date
        return course;
      } else {
        throw Exception('Failed to fetch course details');
      }
    } catch (e) {
      print('Error fetching course details: $e');
      throw e;
    }
  }

  Future<void> createCourse(
    String name,
    String description,
    String? imageUrl,
  ) async {
    // Fetch existing courses to check for uniqueness
    await fetchCourses(); // Ensures DataStore has the latest courses

    // Check for uniqueness of course name and description
    final existingCourses = DataStore.getAllCourses();
    final isDuplicate = existingCourses.any((course) =>
        course.name.toLowerCase() == name.toLowerCase() &&
        course.description.toLowerCase() == description.toLowerCase());

    if (isDuplicate) {
      print('Course with the same name and description already exists.');
      throw Exception(
          'Course with the same name and description already exists.');
    }

    // Proceed to create the course if unique
    final url = Uri.parse(baseUrl + 'courses/');
    print(_token);

    final body = {
      'name': name,
      'description': description,
    };

    if (imageUrl != null) {
      body['image'] = imageUrl;
    }

    final response = await http.post(
      url,
      headers: {
        'Authorization': 'Bearer $_token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode(body),
    );

    if (response.statusCode == 201) {
      // Success: The course was created.
      print('Course created successfully.');

      // Re-fetch courses to update the DataStore
      await fetchCourses();
      print('Courses updated successfully.');
    } else {
      // Handle error
      print('Failed to create course: ${response.body}');
      throw Exception('Failed to create course');
    }
  }

  // Modules

  // Fetch Modules
  Future<void> fetchModules(int courseId) async {
    try {
      final response = await http.get(
        Uri.parse(baseUrl + 'modules/?course_id=$courseId'),
        headers: {
          'Authorization': 'Bearer $_token',
        },
      );

      if (response.statusCode == 200) {
        List<dynamic> modulesJson = json.decode(response.body);
        DataStore.setModules(courseId, modulesJson);
      } else {
        throw Exception('Failed to load modules');
      }
    } catch (e) {
      print('Error fetching modules: $e');
      throw e;
    }
  }

  // Create Module
  Future<bool> createModule(
      int courseId, String title, String description) async {
    final url = Uri.parse(baseUrl + 'modules/');

    try {
      final response = await http.post(
        url,
        headers: {
          'Authorization': 'Bearer $_token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'course': courseId, // Ensure this matches your API's expected key
          'title': title,
          'description': description,
        }),
      );

      if (response.statusCode == 201) {
        print('Module created successfully.');
        await fetchModules(courseId); // Refresh the list of modules
        return true;
      } else {
        print('Failed to create module: ${response.body}');
        return false;
      }
    } catch (error) {
      print('Error creating module: $error');
      return false;
    }
  }

  // Update Module
  Future<bool> updateModule(
      int moduleId, int courseId, String title, String description) async {
    final url = Uri.parse(baseUrl + 'modules/$moduleId/');

    try {
      final response = await http.put(
        url,
        headers: {
          'Authorization': 'Bearer $_token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'course': courseId, // Ensure this matches your API's expected key
          'title': title,
          'description': description,
        }),
      );

      if (response.statusCode == 200) {
        print('Module updated successfully.');
        await fetchModules(courseId); // Refresh the list of modules
        return true;
      } else {
        print('Failed to update module: ${response.body}');
        return false;
      }
    } catch (error) {
      print('Error updating module: $error');
      return false;
    }
  }

  // Delete Module
  Future<void> deleteModule(int moduleId, int courseId) async {
    final url = Uri.parse(baseUrl + 'modules/$moduleId/');

    final response = await http.delete(
      url,
      headers: {
        'Authorization': 'Bearer $_token',
      },
    );

    if (response.statusCode == 204) {
      print('Module deleted successfully.');
      await fetchModules(courseId); // Re-fetch modules after deletion
    } else {
      print('Failed to delete module: ${response.body}');
      throw Exception('Failed to delete module');
    }
  }

  // Enroll
  // Enroll in a Course
  Future<void> enrollInCourse(int courseId) async {
    final url = Uri.parse(baseUrl + 'courses/$courseId/enroll/');

    final response = await http.post(
      url,
      headers: {
        'Authorization': 'Bearer $_token',
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode == 200 || response.statusCode == 201) {
      print('Enrolled in course successfully.');
      // Optionally, you can fetch the course details again to update the enrolled students list
      await fetchCourseDetail(courseId);
    } else {
      print('Failed to enroll in course: ${response.body}');
      throw Exception('Failed to enroll in course');
    }
  }

  // Fetch Course Details (including enrolled students)
  Future<void> fetchCourseDetail(int courseId) async {
    try {
      final response = await http.get(
        Uri.parse(baseUrl + 'courses/$courseId/'),
        headers: {
          'Authorization': 'Bearer $_token',
        },
      );

      if (response.statusCode == 200) {
        final courseJson = json.decode(response.body);
        DataStore.addCourse(
            courseJson); // Update DataStore with fetched course details
      } else {
        throw Exception('Failed to load course details');
      }
    } catch (e) {
      print('Error fetching course details: $e');
      throw e;
    }
  }
}
