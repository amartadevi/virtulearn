import 'dart:convert'; // Added to handle JSON encoding/decoding
import 'package:http/http.dart' as http;

class Datastore {
  static Map<int, Course> courses = {};

  static void addCourse(Course course) {
    courses[course.id!] = course;
  }

  static Course? getCourse(int id) {
    return courses[id];
  }

  static void removeCourse(int id) {
    courses.remove(id);
  }

  static List<Course> getAllCourses() {
    return courses.values.toList();
  }
}

class User {
  String? username;
  String? token;
  int? id;
  String? imageUrl;
  String? role;
  String? email;

  User({
    required this.username,
    required this.id,
    required this.imageUrl,
    required this.token,
    required this.role,
    required this.email,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      username: json['user']['username'],
      id: json['user']['id'],
      role: json['user']['role'],
      imageUrl: json['user']['image'],
      token: json['access'],
      email: json['user']['email'],
    );
  }

  User getUserProfile() {
    return User(
      username: this.username,
      id: this.id,
      imageUrl: this.imageUrl,
      email: this.email,
      token: this.token,
      role: this.role,
    );
  }

  bool isStudent() {
    return role == 'student';
  }

  void display() {
    print('Username: $username');
    print('Email: $email');
    print('Token: $token');
  }
}

class Course {
  final int? id;
  final String? name;
  final String? code;
  final String? description;
  final String? createdByUsername;
  final String? createdByRole;
  final List<String?> students;
  final String imageUrl;

  Course({
    required this.id,
    required this.name,
    required this.code,
    required this.description,
    required this.createdByUsername,
    required this.createdByRole,
    required this.students,
    required this.imageUrl,
  });

  factory Course.fromJson(Map<String, dynamic> json) {
    return Course(
      id: json['id'],
      name: json['name'],
      code: json['code'],
      description: json['description'],
      createdByUsername: json['created_by']['username'],
      createdByRole: json['created_by']['role'],
      students: List<String>.from(json['students']),
      imageUrl: json['image'],
    );
  }
}

late User user;

Future<void> login(String username, String password) async {
  String baseUrl = 'http://127.0.0.1:8000/api/users/login/';
  final response = await http.post(
    Uri.parse(baseUrl),
    headers: {
      'Content-Type': 'application/json',
    },
    body: jsonEncode({
      "username": username,
      "password": password,
    }),
  );

  if (response.statusCode == 200) {
    final jsonResponse = jsonDecode(response.body); // Decode the response body
    user = User.fromJson(jsonResponse);
  } else {
    print('Login failed: ${response.statusCode}');
    print('Response body: ${response.body}');
  }
}

Future<void> getCourses(String? token) async {
  String baseUrl = 'http://127.0.0.1:8000/api/courses/';
  final response = await http.get(
    Uri.parse(baseUrl),
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ${token}',
    },
  );

  if (response.statusCode == 200) {
    List<dynamic> jsonResponse =
        jsonDecode(response.body); // Decode the response as a List
    Datastore.courses = {
      for (var courseJson in jsonResponse)
        Course.fromJson(courseJson).id!: Course.fromJson(courseJson)
    }; // Convert each JSON object into a Course instance and add it to the Datastore

    // Print the courses to verify
    Datastore.getAllCourses().forEach((course) {
      print(
          'Course ID: ${course.id}, Course: ${course.name}, Created by: ${course.createdByUsername}, Course Description: ${course.description}');
    });
  } else {
    print('Failed to load courses: ${response.statusCode}');
    print('Response body: ${response.body}');
  }
}

Future<void> createCourse(
    String? name, String? description, String? image, String? token) async {
  String baseUrl = 'http://127.0.0.1:8000/api/courses/';
  final response = await http.post(
    Uri.parse(baseUrl),
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    },
    body: jsonEncode({
      "name": name,
      "description": description,
      "image": image,
    }),
  );

  if (response.statusCode == 201) {
    print('Course created successfully');
  } else {
    print('Failed to create course: ${response.statusCode}');
  }
}

Future<void> deleteCourse(int? id, String? token) async {
  String baseUrl = 'http://127.0.0.1:8000/api/courses/$id/';
  final response = await http.delete(
    Uri.parse(baseUrl),
    headers: {
      'Authorization': 'Bearer $token',
    },
  );

  if (response.statusCode == 204) {
    print('Course deleted Successfully');
    Datastore.removeCourse(id!); // Remove the course from the datastore
  } else {
    print('Failed to delete course: ${response.statusCode}');
  }
}

void main() async {
  await login(
      'teacher', '123123'); // Call login function and wait for it to complete
  user.getUserProfile();
  await getCourses(user.token);
  print(Datastore.getAllCourses()); // Use the new method to get all courses
  // await createCourse('name', 'description', 'image_url', user.token);
  // await deleteCourse(2, user.token);
}
