import 'package:provider/provider.dart';
import 'package:provider/single_child_widget.dart';

import '../view_models/auth_view_model.dart';
import '../view_models/course_view_model.dart';
import '../view_models/enrollment_view_model.dart';
import '../view_models/module_view_model.dart';
import '../view_models/note_view_model.dart';
import '../view_models/quiz_view_model.dart';
import '../view_models/result_view_model.dart';

class AppProviders {
  static List<SingleChildWidget> providers() {
    return [
      // AuthViewModel provides the User and manages authentication state
      ChangeNotifierProvider(create: (_) => AuthViewModel()),

      // CourseViewModel depends on AuthViewModel for the user's token
      ChangeNotifierProxyProvider<AuthViewModel, CourseViewModel>(
        create: (_) => CourseViewModel(),
        update: (context, auth, courses) {
          courses?.updateToken(auth.user.token);
          return courses ?? CourseViewModel();
        },
      ),

      // ModuleViewModel depends on AuthViewModel for the user's token
      ChangeNotifierProxyProvider<AuthViewModel, ModuleViewModel>(
        create: (_) => ModuleViewModel(),
        update: (context, auth, modules) {
          modules?.updateToken(auth.user.token);
          return modules ?? ModuleViewModel();
        },
      ),

      // NoteViewModel depends on AuthViewModel for the user's token
      ChangeNotifierProxyProvider<AuthViewModel, NoteViewModel>(
        create: (_) => NoteViewModel(),
        update: (context, auth, notes) {
          notes?.updateToken(auth.user.token);
          return notes ?? NoteViewModel();
        },
      ),

      // QuizViewModel depends on AuthViewModel for the user's token
      ChangeNotifierProxyProvider<AuthViewModel, QuizViewModel>(
        create: (_) => QuizViewModel(),
        update: (context, auth, quizzes) {
          quizzes?.updateToken(auth.user.token);
          return quizzes ?? QuizViewModel();
        },
      ),

      // ResultViewModel depends on AuthViewModel for the user's token
      ChangeNotifierProxyProvider<AuthViewModel, ResultViewModel>(
        create: (_) => ResultViewModel(),
        update: (context, auth, results) {
          results?.updateToken(auth.user.token);
          return results ?? ResultViewModel();
        },
      ),

      // EnrollmentViewModel depends on AuthViewModel for the user's token
      ChangeNotifierProxyProvider<AuthViewModel, EnrollmentViewModel>(
        create: (_) => EnrollmentViewModel(),
        update: (context, auth, enrollments) {
          enrollments?.updateToken(auth.user.token);
          return enrollments ?? EnrollmentViewModel();
        },
      ),
    ];
  }
}
