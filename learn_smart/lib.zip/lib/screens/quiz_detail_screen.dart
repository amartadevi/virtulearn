import 'package:flutter/material.dart';

import 'package:learn_smart/screens/widgets/app_bar.dart';
import 'package:learn_smart/view_models/quiz_view_model.dart';
import 'package:provider/provider.dart';

class QuizDetailScreen extends StatefulWidget {
  final int quizId;
  final int moduleId;

  QuizDetailScreen({required this.quizId, required this.moduleId});

  @override
  _QuizDetailScreenState createState() => _QuizDetailScreenState();
}

class _QuizDetailScreenState extends State<QuizDetailScreen> {
  String selectedOption = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<QuizViewModel>(context, listen: false)
          .fetchQuizzes(widget.moduleId);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'Quiz'),
      body: Consumer<QuizViewModel>(
        builder: (context, quizViewModel, child) {
          if (quizViewModel.isLoading) {
            return Center(child: CircularProgressIndicator());
          } else if (quizViewModel.hasError) {
            return Center(child: Text('Error loading quiz'));
          } else {
            final quiz = quizViewModel.quizzes
                .firstWhere((q) => q['id'] == widget.quizId);
            return Column(
              children: [
                _buildQuizHeader(quiz),
                Expanded(
                  child: _buildQuestionList(quiz['questions']),
                ),
                _buildNextButton(),
              ],
            );
          }
        },
      ),
    );
  }

  Widget _buildQuizHeader(Map<String, dynamic> quiz) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            'Question ${quiz['id']} / ${quiz['questions'].length}',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
          ),
          SizedBox(height: 16),
          CircleAvatar(
            radius: 30,
            backgroundColor: Colors.green,
            child: Text(
              '30',
              style: TextStyle(fontSize: 24, color: Colors.white),
            ),
          ),
          SizedBox(height: 16),
          Text(
            quiz['title'],
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildQuestionList(List<dynamic> questions) {
    return ListView.builder(
      itemCount: questions.length,
      itemBuilder: (context, index) {
        final question = questions[index];
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                question['question_text'],
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
              ),
              SizedBox(height: 16),
              _buildOption(question['option_a'], 'A'),
              _buildOption(question['option_b'], 'B'),
              _buildOption(question['option_c'], 'C'),
              _buildOption(question['option_d'], 'D'),
            ],
          ),
        );
      },
    );
  }

  Widget _buildOption(String optionText, String optionValue) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Radio(
            value: optionValue,
            groupValue: selectedOption,
            onChanged: (value) {
              setState(() {
                selectedOption = value.toString();
              });
            },
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              optionText,
              style: TextStyle(fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNextButton() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ElevatedButton(
        onPressed: () {
          // Handle next button logic
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.green,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(50),
          ),
          padding: EdgeInsets.symmetric(vertical: 16),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Next',
              style: TextStyle(fontSize: 18, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
