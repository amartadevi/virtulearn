import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:learn_smart/screens/widgets/app_bar.dart';
import 'package:learn_smart/view_models/auth_view_model.dart';
import 'package:learn_smart/view_models/result_view_model.dart';
import 'package:provider/provider.dart';

class ResultScreen extends StatefulWidget {
  final int quizId;
  final int moduleId;

  ResultScreen({required this.quizId, required this.moduleId});

  @override
  _ResultScreenState createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final authViewModel = Provider.of<AuthViewModel>(context, listen: false);
      final resultViewModel =
          Provider.of<ResultViewModel>(context, listen: false);

      resultViewModel.updateToken(authViewModel.user.token);
      resultViewModel.fetchResults(widget.quizId, widget.moduleId);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'Quiz Results'),
      body: Consumer<ResultViewModel>(
        builder: (context, resultViewModel, child) {
          if (resultViewModel.isLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (resultViewModel.hasError) {
            return Center(
              child: Text('Error: ${resultViewModel.errorMessage}'),
            );
          } else if (resultViewModel.results.isEmpty) {
            return const Center(child: Text('No results available.'));
          } else {
            return _buildResultList(resultViewModel);
          }
        },
      ),
    );
  }

  Widget _buildResultList(ResultViewModel resultViewModel) {
    return ListView.builder(
      itemCount: resultViewModel.results.length,
      itemBuilder: (context, index) {
        final result = resultViewModel.results[index];
        return ListTile(
          title: Text('Score: ${result['score']}%'),
          subtitle: Text('Date: ${result['date_taken']}'),
          onTap: () {
            Get.toNamed('/result-detail', arguments: {
              'resultId': result['id'],
              'quizId': widget.quizId,
              'moduleId': widget.moduleId,
            });
          },
        );
      },
    );
  }
}
