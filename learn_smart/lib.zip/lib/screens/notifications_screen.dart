import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:learn_smart/view_models/auth_view_model.dart';
import 'package:learn_smart/view_models/enrollment_view_model.dart';
import 'package:learn_smart/screens/widgets/app_bar.dart';

class NotificationsScreen extends StatefulWidget {
  @override
  _NotificationsScreenState createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final enrollmentViewModel =
          Provider.of<EnrollmentViewModel>(context, listen: false);
      final authViewModel = Provider.of<AuthViewModel>(context, listen: false);

      // Ensure that the token is up-to-date before fetching requests
      enrollmentViewModel.updateToken(authViewModel.user.token);

      if (authViewModel.user.token != null) {
        print('Token before fetching requests: ${authViewModel.user.token}');
        await enrollmentViewModel
            .fetchEnrollmentRequests(authViewModel.user.role!);
      } else {
        print('Token is null, cannot fetch enrollment requests');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final enrollmentViewModel = Provider.of<EnrollmentViewModel>(context);
    final authViewModel = Provider.of<AuthViewModel>(context);

    return Scaffold(
      appBar: CustomAppBar(title: 'Notifications'),
      body: enrollmentViewModel.isLoading
          ? Center(child: CircularProgressIndicator())
          : enrollmentViewModel.hasError
              ? Center(child: Text('Error fetching notifications'))
              : ListView.builder(
                  itemCount: enrollmentViewModel.enrollmentRequests.length,
                  itemBuilder: (context, index) {
                    final request =
                        enrollmentViewModel.enrollmentRequests[index];
                    return ListTile(
                      title: Text(
                          '${request['course_name']} - ${request['student_username']}'),
                      subtitle: Text('Status: ${request['status']}'),
                      trailing: authViewModel.user.role == 'teacher'
                          ? Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: Icon(Icons.check),
                                  onPressed: () async {
                                    await enrollmentViewModel
                                        .approveEnrollment(request['id']);
                                    final snackBar = SnackBar(
                                      content: Text(enrollmentViewModel.hasError
                                          ? 'Failed to approve request'
                                          : 'Request approved'),
                                    );
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(snackBar);
                                  },
                                ),
                                IconButton(
                                  icon: Icon(Icons.close),
                                  onPressed: () async {
                                    await enrollmentViewModel
                                        .denyEnrollment(request['id']);
                                    final snackBar = SnackBar(
                                      content: Text(enrollmentViewModel.hasError
                                          ? 'Failed to deny request'
                                          : 'Request denied'),
                                    );
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(snackBar);
                                  },
                                ),
                              ],
                            )
                          : null,
                    );
                  },
                ),
    );
  }
}
