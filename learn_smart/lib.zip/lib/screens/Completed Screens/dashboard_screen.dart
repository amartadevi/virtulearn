import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:learn_smart/screens/widgets/app_bar.dart';
import 'package:learn_smart/screens/widgets/bottom_navigation.dart';
import 'package:learn_smart/models/datastore.dart';
import 'package:motion_tab_bar_v2/motion-tab-controller.dart';
import '../../api_service.dart';
import '../../models/course.dart';
import '../../view_models/auth_view_model.dart';

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with TickerProviderStateMixin {
  late MotionTabBarController _motionTabBarController;
  int _selectedIndex = 0;
  late ApiService _apiService;

  @override
  void initState() {
    super.initState();
    _motionTabBarController = MotionTabBarController(
      initialIndex: 0,
      length: 4,
      vsync: this,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final authViewModel = Provider.of<AuthViewModel>(context, listen: false);
      _apiService = ApiService(baseUrl: 'http://10.0.2.2:8000/api/');
      _apiService.updateToken(authViewModel.user.token ?? '');

      await _apiService.fetchCourses(); // Fetch and store courses in DataStore
      setState(() {}); // Refresh the UI after fetching courses
    });
  }

  @override
  void dispose() {
    _motionTabBarController.dispose();
    super.dispose();
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
      _motionTabBarController.index = index;
    });
  }

  Future<void> _showCreateCourseDialog() async {
    final nameController = TextEditingController();
    final descriptionController = TextEditingController();

    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Create Course'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                TextField(
                  controller: nameController,
                  decoration: InputDecoration(hintText: 'Course Name'),
                ),
                TextField(
                  controller: descriptionController,
                  decoration: InputDecoration(hintText: 'Course Description'),
                ),
                // Image picker can be added here for optional image upload
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('Create'),
              onPressed: () async {
                await _apiService.createCourse(
                  nameController.text,
                  descriptionController.text,
                  null, // Handle image URL if needed
                );
                Navigator.of(context).pop();
                setState(() {
                  // Refresh the courses after creation
                });
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: 'Home',
        onMenuPressed: () {
          // Handle menu press
        },
        onSearchPressed: () {
          // Handle search press
        },
      ),
      body: SafeArea(
        child: _buildCourseListScreen(context),
      ),
      bottomNavigationBar: BottomNavigation(
        controller: _motionTabBarController,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
      floatingActionButton:
          Provider.of<AuthViewModel>(context, listen: false).user.isStudent()
              ? null
              : FloatingActionButton(
                  onPressed: _showCreateCourseDialog,
                  child: Icon(Icons.add),
                ),
    );
  }

  Widget _buildCourseListScreen(BuildContext context) {
    final courses = DataStore.getAllCourses(); // Get courses from DataStore

    if (courses.isEmpty) {
      return Center(
        child: Text('No courses available'),
      );
    }

    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionTitle('My Courses'),
            const SizedBox(height: 10),
            _buildCourseGrid(courses),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: Theme.of(context)
              .textTheme
              .headlineLarge
              ?.copyWith(fontWeight: FontWeight.bold),
        ),
        TextButton(
          onPressed: () {},
          child: Text(
            'See All',
            style: Theme.of(context)
                .textTheme
                .bodyLarge
                ?.copyWith(color: const Color(0xff00A2E8)),
          ),
        ),
      ],
    );
  }

  Widget _buildCourseGrid(List<Course> courses) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: courses.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.92,
        crossAxisSpacing: 15,
        mainAxisSpacing: 15,
      ),
      itemBuilder: (context, index) {
        final course = courses[index];
        return _buildCourseCard(course);
      },
    );
  }

  Widget _buildCourseCard(Course course) {
    final user = Provider.of<AuthViewModel>(context, listen: false).user;

    return GestureDetector(
      onTap: () async {
        final isEnrolled = course.students.contains(user.id.toString());

        Get.toNamed('/course/${course.id}', arguments: {
          'isEnrolled': isEnrolled,
        });
      },
      child: Card(
        elevation: 3,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
              child: course.imageUrl != null && course.imageUrl!.isNotEmpty
                  ? Image.network(
                      course.imageUrl!,
                      fit: BoxFit.cover,
                      height: 100,
                      width: double.infinity,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          height: 100,
                          width: double.infinity,
                          color: Colors.grey,
                          child: Center(
                            child: Text(
                              'Image not available',
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        );
                      },
                    )
                  : Container(
                      height: 100,
                      width: double.infinity,
                      color: Colors.grey,
                      child: Center(
                        child: Text(
                          'No Image ${course.imageUrl}',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      course.name,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '${course.students.length} Students',
                          style:
                              const TextStyle(color: Colors.grey, fontSize: 12),
                        ),
                        if (user.isStudent())
                          IconButton(
                            onPressed: () async {
                              final snackBar = SnackBar(
                                content: Text('Enrollment logic needed'),
                              );
                              ScaffoldMessenger.of(context)
                                  .showSnackBar(snackBar);
                            },
                            icon: Icon(
                              Icons.add,
                              color: Colors.blue,
                              size: 20,
                            ),
                            padding: EdgeInsets.zero,
                            constraints: BoxConstraints(),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
