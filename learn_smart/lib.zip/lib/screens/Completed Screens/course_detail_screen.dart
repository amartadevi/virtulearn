import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:learn_smart/screens/widgets/app_bar.dart';
import 'package:learn_smart/models/datastore.dart';
import 'package:learn_smart/api_service.dart';
import 'package:learn_smart/view_models/auth_view_model.dart';
import 'package:provider/provider.dart';

class CourseDetailScreen extends StatefulWidget {
  final int courseId;

  CourseDetailScreen({Key? key, required this.courseId}) : super(key: key);

  @override
  _CourseDetailScreenState createState() => _CourseDetailScreenState();
}

class _CourseDetailScreenState extends State<CourseDetailScreen> {
  late ApiService _apiService;
  bool _isLoading = true;
  bool _hasError = false;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final authViewModel = Provider.of<AuthViewModel>(context, listen: false);
      _apiService = ApiService(baseUrl: 'http://10.0.2.2:8000/api/');
      _apiService.updateToken(authViewModel.user.token ?? '');

      try {
        await _apiService.getCourseDetail(widget.courseId);
        await _apiService.fetchModules(widget.courseId);
        setState(() {
          _isLoading = false;
        });
      } catch (e) {
        setState(() {
          _hasError = true;
          _errorMessage = e.toString();
        });
      }
    });
  }

  bool _isEnrolled(AuthViewModel authViewModel) {
    final course = DataStore.getCourse(widget.courseId);
    return course?.students.contains(authViewModel.user.username) ?? false;
  }

  @override
  Widget build(BuildContext context) {
    final authViewModel = Provider.of<AuthViewModel>(context);
    final course = DataStore.getCourse(widget.courseId);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        title: (course?.name).toString(),
        // centerTitle: true,
        onMenuPressed: () {
          _showOptionsDialog(context);
        },
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _hasError
              ? Center(child: Text(_errorMessage))
              : SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildHeader(),
                        const SizedBox(height: 24),
                        _buildCourseOverview(),
                        const SizedBox(height: 24),
                        Text(
                          'Modules',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 10),
                        _buildModulesList(),
                      ],
                    ),
                  ),
                ),
      bottomNavigationBar:
          authViewModel.user.isStudent() && !_isEnrolled(authViewModel)
              ? Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        _showEnrollDialog(context, widget.courseId);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xff0095FF),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                      ),
                      child: const Text(
                        'Enroll',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                )
              : null,
      floatingActionButton:
          authViewModel.user.isStudent() ? null : _buildFAB(context),
    );
  }

  Widget _buildHeader() {
    final course = DataStore.getCourse(widget.courseId);
    final courseImage = course?.imageUrl;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: courseImage != null
              ? Image.network(
                  courseImage,
                  height: 200,
                  width: double.infinity,
                  fit: BoxFit.cover,
                )
              : Image.asset(
                  'assets/icons/default_course_image.png',
                  height: 200,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            CircleAvatar(
              backgroundImage: AssetImage('assets/screens/background.png'),
              radius: 20,
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Instructed by',
                  style: TextStyle(color: Colors.grey, fontSize: 12),
                ),
                Text(
                  course?.createdByUsername ?? 'Not Found!',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildCourseOverview() {
    final course = DataStore.getCourse(widget.courseId);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Course Overview',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        Text(
          course?.description ?? '',
          style: TextStyle(color: Colors.grey[600], height: 1.5),
        ),
      ],
    );
  }

  Widget _buildModulesList() {
    final modules = DataStore.getModules(widget.courseId);
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: modules.length,
      itemBuilder: (context, index) {
        final module = modules[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 10.0),
          child: ModuleCard(
            module: Module(
              title: module['title'] ?? '',
              author: module['description'] ?? '',
              imagePath:
                  'assets/icons/flutter.jpg', // Replace with actual image URL if available
            ),
            onEdit: () {
              if (!Provider.of<AuthViewModel>(context, listen: false)
                  .user
                  .isStudent()) {
                _showEditModuleDialog(context, module);
              }
            },
            onDelete: () async {
              if (!Provider.of<AuthViewModel>(context, listen: false)
                  .user
                  .isStudent()) {
                await _apiService.deleteModule(module['id'], widget.courseId);
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Module deleted')),
                );
              }
            },
            onTap: () {
              Get.toNamed('/module-detail', arguments: {
                'moduleId': module['id'],
                'title': module['title'],
              });
            },
          ),
        );
      },
    );
  }

  Widget _buildFAB(BuildContext context) {
    return FloatingActionButton(
      onPressed: () {
        _showCreateModuleDialog(context);
      },
      child: Icon(Icons.add),
    );
  }

  void _showOptionsDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: Icon(Icons.create),
                title: Text('Create'),
                onTap: () {
                  Navigator.of(context).pop();
                  _showCreateModuleDialog(context);
                },
              ),
              ListTile(
                leading: Icon(Icons.edit),
                title: Text('Update'),
                onTap: () {
                  Navigator.of(context).pop();
                  // Implement update functionality
                },
              ),
              ListTile(
                leading: Icon(Icons.delete),
                title: Text('Delete'),
                onTap: () {
                  Navigator.of(context).pop();
                  // Implement delete functionality
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _showCreateModuleDialog(BuildContext context) {
    final _formKey = GlobalKey<FormState>();
    String? _title;
    String? _description;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Create Module'),
          content: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  decoration: const InputDecoration(labelText: 'Title'),
                  onSaved: (value) {
                    _title = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a title';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  decoration: const InputDecoration(labelText: 'Description'),
                  onSaved: (value) {
                    _description = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a description';
                    }
                    return null;
                  },
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (_formKey.currentState!.validate()) {
                  _formKey.currentState!.save();
                  await _apiService.createModule(
                      widget.courseId, _title!, _description!);
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Module created successfully'),
                    ),
                  );
                }
              },
              child: const Text('Create'),
            ),
          ],
        );
      },
    );
  }

  void _showEditModuleDialog(BuildContext context, dynamic module) {
    final _formKey = GlobalKey<FormState>();
    String? _title = module['title'];
    String? _description = module['description'];

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Edit Module'),
          content: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  initialValue: _title,
                  decoration: const InputDecoration(labelText: 'Title'),
                  onSaved: (value) {
                    _title = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a title';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  initialValue: _description,
                  decoration: const InputDecoration(labelText: 'Description'),
                  onSaved: (value) {
                    _description = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a description';
                    }
                    return null;
                  },
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (_formKey.currentState!.validate()) {
                  _formKey.currentState!.save();
                  await _apiService.updateModule(
                      module['id'], widget.courseId, _title!, _description!);
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Module updated successfully'),
                    ),
                  );
                }
              },
              child: const Text('Update'),
            ),
          ],
        );
      },
    );
  }

  void _showEnrollDialog(BuildContext context, int courseId) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Enroll in Course'),
          content:
              const Text('Are you sure you want to enroll in this course?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                await _apiService.enrollInCourse(courseId);
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Enrollment request sent')),
                );
              },
              child: const Text('Enroll'),
            ),
          ],
        );
      },
    );
  }
}

class ModuleCard extends StatelessWidget {
  final Module module;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;
  final VoidCallback? onTap;

  ModuleCard({
    required this.module,
    this.onEdit,
    this.onDelete,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: module.color,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Image.asset(
                module.imagePath,
                width: 50,
                height: 50,
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      module.title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      module.author,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              if (onEdit != null)
                IconButton(
                  icon: const Icon(Icons.edit, color: Colors.white),
                  onPressed: onEdit,
                ),
              if (onDelete != null)
                IconButton(
                  icon: const Icon(Icons.delete, color: Colors.white),
                  onPressed: onDelete,
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class Module {
  final String title;
  final String author;
  final String imagePath;
  final Color color;

  Module({
    required this.title,
    required this.author,
    required this.imagePath,
    this.color = Colors.blue,
  });
}
