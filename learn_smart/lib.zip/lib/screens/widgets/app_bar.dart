import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:learn_smart/view_models/auth_view_model.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final VoidCallback? onMenuPressed;
  final VoidCallback? onSearchPressed;
  final VoidCallback? onBackPressed;
  final VoidCallback? onCreatePressed;
  final VoidCallback? onUpdatePressed;
  final VoidCallback? onDeletePressed;

  const CustomAppBar({
    required this.title,
    this.onMenuPressed,
    this.onSearchPressed,
    this.onBackPressed,
    this.onCreatePressed,
    this.onUpdatePressed,
    this.onDeletePressed,
  });

  bool get _isHome => title == 'Home';

  @override
  Widget build(BuildContext context) {
    final authViewModel = Provider.of<AuthViewModel>(context);
    final user = authViewModel.user;
    final username = user.username ?? "User";
    String? baseUrl = 'http://10.0.2.2:8000/';
    final profileImage = user.imageUrl != null
        ? baseUrl + user.imageUrl.toString()
        : 'assets/icons/default_profile.png';

    return Container(
      padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
      decoration: BoxDecoration(
        color: Colors.blue,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(20),
          bottomRight: Radius.circular(20),
        ),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                if (!_isHome)
                  IconButton(
                    icon: Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: onBackPressed ?? () => Navigator.pop(context),
                  ),
                if (_isHome)
                  CircleAvatar(
                    radius: 20,
                    backgroundImage: profileImage.isNotEmpty
                        ? NetworkImage(profileImage)
                        : const AssetImage('assets/icons/default_profile.png')
                            as ImageProvider,
                  ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (_isHome)
                          Text(
                            'Hello $username,',
                            style: const TextStyle(
                                color: Colors.white, fontSize: 16),
                          ),
                        Text(
                          _isHome ? 'Good Morning' : title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                if (_isHome)
                  IconButton(
                    icon: const Icon(Icons.notifications_none,
                        color: Colors.white),
                    onPressed: onMenuPressed ?? () {},
                  ),
                if (!_isHome)
                  PopupMenuButton<String>(
                    icon: Icon(Icons.more_vert, color: Colors.white),
                    onSelected: (String result) {
                      switch (result) {
                        case 'Create':
                          if (onCreatePressed != null) onCreatePressed!();
                          break;
                        case 'Update':
                          if (onUpdatePressed != null) onUpdatePressed!();
                          break;
                        case 'Delete':
                          if (onDeletePressed != null) onDeletePressed!();
                          break;
                      }
                    },
                    itemBuilder: (BuildContext context) => [
                      const PopupMenuItem(
                        value: 'Create',
                        child: Text('Create'),
                      ),
                      const PopupMenuItem(
                        value: 'Update',
                        child: Text('Update'),
                      ),
                      const PopupMenuItem(
                        value: 'Delete',
                        child: Text('Delete'),
                      ),
                    ],
                  ),
              ],
            ),
          ),
          if (_isHome)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: SearchBar(onSearchPressed: onSearchPressed),
            ),
        ],
      ),
    );
  }

  @override
  Size get preferredSize =>
      _isHome ? const Size.fromHeight(180) : const Size.fromHeight(80);
}

class SearchBar extends StatelessWidget {
  final VoidCallback? onSearchPressed;

  const SearchBar({this.onSearchPressed});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
      ),
      child: TextField(
        onTap: onSearchPressed,
        decoration: const InputDecoration(
          hintText: 'Search Course',
          suffixIcon: Icon(Icons.search),
          border: InputBorder.none,
          contentPadding: EdgeInsets.all(20),
        ),
      ),
    );
  }
}
